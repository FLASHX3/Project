/*  Client Extensions for Back Orifice XP
    Copyright (C) 2,004 - 2,005 Javier Aroche
	
	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

> Autor: Javier Aroche, j_aroche at users dot sourceforge dot net */

#ifndef __CLIEXTMAIH_H_
#define __CLIEXTMAIH_H_

#include <srv_linkage.h>
#include "serverlist.h"
#include "trayicon.h"

// Client Extensions Strings structure.
typedef struct {

	// Server List Strings.
	char	*pSpace;
	char	*sSLtvroot;			// TreeView Root: BOXP Neighborhood
	char	*sSLttcatadd;		// ToolTip "Add Category"
	char	*sSLttcatedit;		// TooTip "Edit Category"
	char	*sSLttcatdel;		// ToolTip "Remove Category"
	char	*sSLttpressenter;	// ToolTip "Press Enter to change the value"
	char	*sSLlblcat;			// Label: "Category:"
	char	*sCatnone;			// Category name: "(None)"

	char	*sSBcatadd;			// StatusBar Msg: Category Added.
	char	*sSBcatedit;		// StatusBar Msg: Category edited.
	char	*sSBcatdel;			// StatusBar Msg: Category removed.
	char	*sSBsrvcat;			// StatusBar Msg: server categorized.

	char	*sErrNullcatname;	// Error msg: category name can't be NULL.
	char	*sErrNulladdress;	// Error msg: address can't be NULL.
	char	*sErrTitle;	

	char	*sACtitulo;			// Titulo: Add Category
	char	*sACscatname;		// Msg: Category name
	char	*sACsok;			// Msg: OK
	char	*sACscancel;		// Msg: Cancel

	char	*sFndSrvthrdname;	// FindSrv Thread name
	char	*sFSallcats;		// Msg: "(All categories)"
} SRVLST_STR;

// Client Extensions Context structure.
typedef struct {
	SRVLST2_CTX	*slctx;			// ServerList Context
	SRVLST_STR	str;			// ServerList Strings
	
	CETRAYICON_CTX *tictx;		// TrayIcon Context.

	// old functions address
	SLC *	(BOAPI *pOldCreateSrvLstDlg)		( struct GS *gs, HWND hParent );
	BOOL 	(CALLBACK *pOldServerListProc)		( HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam );
	SLC *	pOldslctx;

	LRESULT	(*pOldMainFrameProc)			( HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam ); // Old Main Frame window procedure.

	bool	(BOAPI *OldSaveDocument)		( struct GS *gs, char *svFile );
	bool	(BOAPI *OldOpenDocument)		( struct GS *gs, char *svFile );

	// other future infos here.
} CLIEXT,CEX;

extern HINSTANCE g_hInstance;
extern BOOL g_bActive;
extern char g_sCliExtendCfg[];
extern CLIEXT *g_Ctx;
extern GS *ggs;


#endif // __CLIEXTMAIH_H_