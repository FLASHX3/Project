/*  Client Extensions for Back Orifice XP
    Copyright (C) 2,004 - 2,005 Javier Aroche
	
	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

> Autor: Javier Aroche, j_aroche at users dot sourceforge dot net */

// ---------------------------------------------------
// serverlist.cpp:
// Source Code of the ServerList Extension
//
// History:
//		(Initial development)
//		> v0.90		16-May-04		* File Added to project
//					29-May-04		* Added code to Add Categories
//					30-May-04		* Edit Category code completed.
//					06-Jun-04		* Sorting Categories and Servers
//									* Remove Categoy code completed.
//					08-Jun-04		* Servers can be categorized.
//									* Redirecting Document functions.
//					12-Jun-04		* SaveDocument and OpenDocument functions begun to
//									  be coded.
//									* Some changes in Dialog procedure for best code.
//					19-Jun-04		* Controls can change server settings.
//									* The list of categorized servers is writed/readed
//									  to/from the document file.
//									* Show texts in the Status Bar.
//					21-Jun-04		* Adding Drag & Drop code for TreeView Control.
//					25-Jun-04		* Strings added to structure.
//					30-Jun-04		* Allow to cancel drag & drop when Escape key is pressed.
//									* Drag & Drop completed.
//					15-Jul-04		* Document format changed.
//					16-Jul-04		* Category status saved in the document
//					17-Jul-04		* beta 5 release
//
//		> v0.91		21-Jul-04		* Context menu added.
//					20-Mar-05		* Fix: check if the ServerList is visible at startup
//					21-Mar-05		* Opt: When starts or removes the plugin and there is a workspace, 
//									  reopens it.
//					15-Jul-05		* New: WM_SETSELECTSRV message added to ServerList. Selects a server 
//									  and does it visible in the list. WM_GETSELECTSRV message returns 
//									  the server selected in the list.
//									* New: FindServerEx dialog added. Allow to find a server in the list 
//									  by his name and address in categories. The messages of this dialog 
//									  are handled in the FindSrvExThread function.
//					23-Jul-05		* Search by category completed.
//					30-Jul-05		* Forces to MainFrame set the right position of Server List.
//									* Adding documentation.
//					07-Aug-05		* Linking main.h header.
//
//		> v0.93		15-Sep-05		* Fix: The Background color of the ServerList isn't repainted when a 
//									  window in from of this is minimized. WM_ERASEBKGND message disabled
//									* Fix: If the MainFrame isn't maximized at the install of ServerList 
//									  it's placed in a wrong position.
// ---------------------------------------------------

#include "main.h"
#include "serverlist.h"
#include "resource.h"
#include <resource.h>
#include <util.h>

BOOL	CALLBACK CategoryAddDlgProc ( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam );
bool	BOAPI SrvLstSaveDocument ( struct GS *gs, char *svFile );
bool	BOAPI SrvLstOpenDocument ( struct GS *gs, char *svFile );
HTREEITEM BOAPI GetTreeItemByCtx(HWND hTree, LPARAM nfo);
int		CALLBACK SortTreeItemsProc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort);
bool	UpdateSrvCRC( GS *gs, SERVER_INFO *nfo );

///////////////////////////////////////////////////////////////////////////
// ReloadWorkspace: Recarga el workspace, asi el ServerList carga los servidores y categorias.
// Argumentos:
// * gs: Puntero a la Estructura Global.
///////////////////////////////////////////////////////////////////////////
// ReloadWorkspace: Reloads the workspace, so the ServerList loads the servers and categories
// Arguments:
// * gs: Pointer to the Global Structure.
///////////////////////////////////////////////////////////////////////////
void BOAPI ReloadWorkspace ( GS *gs )
{
	bool	bOpenDoc=false;
	API		*api = &gs->api;
	CLI		*cli = gs->cli;

	// should save the changes?
	if ( cli->bSave ) {
		if ( api->pMessageBox(cli->hMainWnd,cli->str.sSaveWrk,cli->str.sAppName,MB_YESNO)==IDYES )
			api->pSendMessage( cli->hMainWnd, WM_COMMAND, IDM_SAVEWRK, 0 );
	}

	if ( *cli->svDocFile ) {
		bOpenDoc=true;
		cli->CloseDocument( gs );
	}
	
	if ( bOpenDoc && *cli->svLastDocFile!=0 )
		cli->OpenDocument( gs, cli->svLastDocFile );
}

///////////////////////////////////////////////////////////////////////////
// InstallServerListExtension: Instala el nuevo ServerList.
// Argumentos:
// * gs: Puntero a la Estructura Global.
///////////////////////////////////////////////////////////////////////////
// InstallServerListExtension: Installs the new ServerList.
// Arguments:
// * gs: Pointer to the Global Structure.
///////////////////////////////////////////////////////////////////////////
void BOAPI InstallServerListExtension ( GS *gs )
{
	FCT		*fct = &gs->fct;
	API		*api = &gs->api;
	CLI		*cli = gs->cli;
	SLC2	*ctx;

	// Create new ServerList
	ctx = (SLC2 *) CreateSrvLstExDlg( gs, cli->pMFrmCtx->hMainFrame );
	if ( ctx==NULL )
		return;

	// store functions addresses
	g_Ctx->pOldServerListProc = cli->pServerListProc;
	g_Ctx->pOldCreateSrvLstDlg = cli->pCreateSrvLstDlg;
	g_Ctx->pOldslctx = cli->pMFrmCtx->srvlist;
	g_Ctx->OldSaveDocument = cli->SaveDocument;
	g_Ctx->OldOpenDocument = cli->OpenDocument;

	// Configure new ServerList
	if ( IsDlgButtonChecked(cli->pMFrmCtx->hSrvList,IDC_SHOW)==BST_CHECKED ) 
		CheckDlgButton(ctx->hSrvList,IDC_SHOW,BST_CHECKED);
	else
		CheckDlgButton(ctx->hSrvList,IDC_SHOW,BST_UNCHECKED);
	api->pSendMessage( ctx->hSrvList, WM_COMMAND, IDC_SHOW, 0 );

	// Is server list visible?
	if ( api->pIsWindowVisible(cli->pMFrmCtx->hSrvList) ) 
		api->pShowWindow( ctx->hSrvList, SW_SHOW );
	else
		api->pShowWindow( ctx->hSrvList, SW_HIDE );

	// Remove old ServerList data.
	cli->pMFrmCtx->srvlist = (SLC *)ctx;
	cli->pCreateSrvLstDlg = CreateSrvLstExDlg;
	cli->pServerListProc = ServerListExProc;
	api->pShowWindow(cli->pMFrmCtx->hSrvList,SW_HIDE); // hide old srv list
	cli->pMFrmCtx->hSrvList = ctx->hSrvList;			// new srvlist window
	cli->OpenDocument = SrvLstOpenDocument;
	cli->SaveDocument = SrvLstSaveDocument;

	/////////////////////////////////////
	// Auto ajustar ventana
	//  Auto size window.
	RECT rc;
	GetWindowRect(cli->hMainWnd,&rc);
	api->pSetWindowPos( ctx->hSrvList, NULL, 0, rc.bottom - ctx->wndheight-70, rc.right-rc.left-5, ctx->wndheight+10, SWP_NOZORDER );
	SendMessage(cli->hMainWnd,WM_REPOSCTRL,0,0);

	ReloadWorkspace( gs );
}

///////////////////////////////////////////////////////////////////////////
// UninstallServerListExtension: Desinstala el nuevo ServerList y muestra 
// el anterior ServerList.
// Argumentos:
// * gs: Puntero a la Estructura Global.
///////////////////////////////////////////////////////////////////////////
// UninstallServerListExtension: Removes the new ServerList and show the 
// old ServerList.
// Arguments:
// * gs: Pointer to the Global Structure.
///////////////////////////////////////////////////////////////////////////
void BOAPI UninstallServerListExtension( GS *gs )
{
	FCT *fct = &gs->fct;
	API *api = &gs->api;
	CLI *cli = gs->cli;

	// Is server list visible?
	if ( api->pIsWindowVisible(cli->pMFrmCtx->hSrvList) && !gs->gv.bStopping) 
		api->pShowWindow( g_Ctx->slctx->hSrvList, SW_SHOW );
	else
		api->pShowWindow( g_Ctx->slctx->hSrvList, SW_HIDE );

	// Delete our ServerList
	api->pDestroyWindow( cli->pMFrmCtx->hSrvList );
	fct->free( cli->pMFrmCtx->srvlist,gs );

	// restore old values
	cli->SaveDocument=g_Ctx->OldSaveDocument;
	cli->OpenDocument=g_Ctx->OldOpenDocument;

	gs->cli->pServerListProc = g_Ctx->pOldServerListProc;
	gs->cli->pCreateSrvLstDlg = g_Ctx->pOldCreateSrvLstDlg;
	cli->pMFrmCtx->srvlist=g_Ctx->pOldslctx;
	cli->pMFrmCtx->hSrvList = g_Ctx->slctx->hSrvList;

	if ( !gs->gv.bStopping )
		ReloadWorkspace( gs );
}

///////////////////////////////////////////////////////////////////////////
// SrvLstSaveDocument: Guarda el contenido del documento actual.
// Argumentos:
// * gs: Puntero a la Estructura Global.
// * sArc: Ruta del archivo donde se guardar� el documento.
///////////////////////////////////////////////////////////////////////////
// SrvLstSaveDocument: Saves the current document contents.
// Arguments:
// * gs: Pointer to the Global Structure.
// * sArc: Path to the file where the document will be save.
///////////////////////////////////////////////////////////////////////////
bool BOAPI SrvLstSaveDocument ( struct GS *gs, char *sArc )
{
	SLC2		*ctx = g_Ctx->slctx;	// nuestro contexto
	API			*api = &gs->api;
	FCT			*fct = &gs->fct;
	VARS		*gv  = &gs->gv;
	HANDLE		hSalida;			// archivo de escritura
	DWORD		dwOp;
	DWORD		nPos;				// Posicion de escritura en el Buffer.
	DWORD		nTam;				// Tama�o maximo del archivo.
	SRVCAT		*pcat;				// Info de la categoria
	SERVER_INFO *nfo;				// Info. del Servidor
	SRVINCAT	sic;				// Servidor en categoria
	BYTE		*pDatos;			// Datos a escribir
	bool		bEstado;			// Estado de la categoria
	TVITEM		tvi;				// Elemento TreeView
	BODOC		*doc;				// Documento BOXP 
	BODOCEX		*de;				// Extension del documento BOXP

	doc = (BODOC *) fct->malloc( sizeof(BODOC), gs );
	if ( doc==NULL ) {
		gv->dwErr = ERR_ALLOCMEM;
		return false;
	}

	de = (BODOCEX *) fct->malloc( sizeof(BODOCEX), gs );
	if ( de==NULL ) {
		gv->dwErr = ERR_ALLOCMEM;
		return false;
	}

	/////////////////////////////////////////////
	// 1. Llamar a la vieja funci�n SaveDocument
	//    Call Old SaveDocument function
	if ( !g_Ctx->OldSaveDocument(gs,sArc) )
		return false;

#ifdef _DEBUG
	if ( gs->Log ) gs->Log->AddStr( gs, " >CliExtend: Saving Categories.\r\n" );
#endif

	/////////////////////////////////////////////
	// 2. Abrir de nuevo el archivo.
	//    Open again the file
	hSalida = api->pCreateFile( sArc, GENERIC_READ|GENERIC_WRITE, 0, NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if ( hSalida==INVALID_HANDLE_VALUE ) {
		gv->dwErr = ERR_FILEOPEN;
		return false;
	}

	/////////////////////////////////////////////
	// 3. Buscar el final del archivo.
	//    Find the file end.

	// Numero de infos guardados. Numbrer of infos stored.
	api->pReadFile( hSalida, doc, sizeof(BODOC), &dwOp, NULL );
	
	if ( dwOp<sizeof(BODOC) ) {
		gv->dwErr = ERR_FILEREAD;
		fct->free( doc, gs );
		fct->free( de, gs );
		api->pCloseHandle( hSalida );
		return false;
	}

	// Mover al final de los infos. Move to the end of infos.
	api->pSetFilePointer( hSalida, doc->sig_estr, NULL, FILE_CURRENT );

	/////////////////////////////////////////////
	// 4. Preparar buffer de salida.
	//    Prepare output buffer.
	tvi.mask = TVIF_PARAM;
	pcat = ctx->pcats;

	// Numero de categorias y servidores en categorias
	while ( pcat!=NULL ) {
		de->nCats++;
		tvi.hItem = TreeView_GetChild( ctx->hList, pcat->itm );
		while( tvi.hItem!=NULL ) {
			de->nServerCat++;
			tvi.hItem = TreeView_GetNextSibling( ctx->hList, tvi.hItem );
		}

		pcat=pcat->sig;
	}

	// no hay categorias que guardar?
	// no are there categories to save?
	if ( de->nCats==0 ) {
		fct->free( doc, gs );
		fct->free( de, gs );
		api->pCloseHandle( hSalida );
		return true;
	}

#ifdef _DEBUG
	if ( gs->Log ) gs->Log->AddStrf( gs, " >CliExtend: Number of Categories: %d.\r\n", de->nCats );
#endif

	// Tama�o = [Info de la Categoria * #de categorias] + [Info de Sevidores en categoria * # de servidores]
	nTam = sizeof(CAT_INFO)*de->nCats + sizeof(SRVINCAT)*de->nServerCat;
	pDatos = (BYTE *) fct->malloc(nTam,gs);
	if ( pDatos==NULL ) {
		gv->dwErr = ERR_ALLOCMEM;
		fct->free( doc, gs );
		fct->free( de, gs );
		api->pCloseHandle( hSalida );
		return false;
	}

	// Copiar datos al buffer.

	// Datos de las categorias
	tvi.mask=TVIF_STATE;
	tvi.stateMask=TVIS_EXPANDED;
	pcat = ctx->pcats;
	nPos = 0;
	while ( pcat!=NULL )
	{
		// nombre de la categoria
		fct->memcpy( pDatos+nPos, pcat->sNombre, 65);
		nPos+= 65;

		// obtener el estado de la categoria
		tvi.hItem = pcat->itm;
		TreeView_GetItem( ctx->hList, &tvi );
		if (tvi.state & TVIS_EXPANDED)
			bEstado = 1; // expandido
		else 
			bEstado = 0; // colapsado

		fct->memcpy( pDatos+nPos, &bEstado, sizeof(bool) );
		nPos += sizeof(BYTE);
		pcat = pcat->sig;
	}

	// Lista de servidores por categoria
	tvi.mask = TVIF_PARAM;
	pcat = ctx->pcats;
	dwOp = 0;
	while ( pcat!=NULL ) {

		sic.dwCatID = pcat->nCRC;

		tvi.hItem = TreeView_GetChild( ctx->hList, pcat->itm );
		while( tvi.hItem!=NULL ) {

			TreeView_GetItem( ctx->hList, &tvi );
			nfo = (SERVER_INFO *)tvi.lParam;
			sic.dwSrvID = nfo->nCRC;

			fct->memcpy( pDatos+nPos, &sic, sizeof(SRVINCAT) );
			nPos += sizeof(SRVINCAT);

			tvi.hItem = TreeView_GetNextSibling( ctx->hList, tvi.hItem );
		}

		pcat=pcat->sig;
	}

	/////////////////////////////////////////////
	// 5. Escribir nuestros infos.
	//    Write our infos.
	api->pWriteFile( hSalida, de, sizeof(BODOCEX), &dwOp, NULL );
	api->pWriteFile( hSalida, pDatos, nTam, &dwOp, NULL );

#ifdef _DEBUG
	if ( gs->Log ) gs->Log->AddStr( gs, " >CliExtend: Done.\r\n" );
#endif

	/////////////////////////////////////////////
	// 6. Salida
	//    Quit
	gv->dwErr = ERR_NO;
	api->pSetEndOfFile( hSalida );
	fct->free( pDatos, gs );
	fct->free( doc, gs );
	fct->free( de, gs );
	api->pCloseHandle( hSalida );
	return true;
}

bool BOAPI SrvLstOpenDocument ( struct GS *gs, char *sArc )
{
	SLC2		*ctx = g_Ctx->slctx;	// Nuestro Contexto
	API			*api = &gs->api;
	FCT			*fct = &gs->fct;
	CLI			*cli = gs->cli;
	VARS		*gv  = &gs->gv;
	DWORD		nID, dwOp;
	DWORD		nPos;				// Posici�n en el buffer.
	DWORD		nTam;				// Tama�o maximo de la lectura
	HANDLE		hEntrada;			// archivo de lectura
	BYTE		*pDatos;			// Datos a procesar
	SRVCAT		*tmp;				// info. de la categoria
	SERVER_INFO	*nfo;				// info del servidor.
	BODOC		*doc;				// Documento BOXP
	BODOCEX		*de;				// Extension del documento BOXP

	/////////////////////////////////////////////
	// 1. Llamar a la vieja funcion OpenDocument
	//    Call to the old function OpenDocument
	if ( !g_Ctx->OldOpenDocument(gs,sArc) )
		return false;

#ifdef _DEBUG
	if ( gs->Log ) gs->Log->AddStr( gs, " >CliExtend: Loading Categories.\r\n" );
#endif

	/////////////////////////////////////////////
	// 2. Abrir de nuevo el archivo.
	//    Open again the file
	hEntrada = api->pCreateFile( sArc, GENERIC_READ, 0, NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if ( hEntrada==INVALID_HANDLE_VALUE ) {
		gv->dwErr = ERR_FILEOPEN;
		return false;
	}

	/////////////////////////////////////////////
	// 3. Buscar el final del del archivo.
	//    Find the file end.

	doc = (BODOC *) fct->malloc(sizeof(BODOC),gs);
	if ( doc==NULL ) {
		gv->dwErr = ERR_ALLOCMEM;
		api->pCloseHandle( hEntrada );
		return false;
	}

	de = (BODOCEX *) fct->malloc( sizeof(BODOCEX),gs);
	if ( de==NULL ) {
		gv->dwErr = ERR_ALLOCMEM;
		api->pCloseHandle( hEntrada );
		fct->free(doc,gs);
		return false;
	}

	// Numero de infos guardados. Numbrer of infos stored.
	api->pReadFile( hEntrada, doc, sizeof(BODOC), &dwOp, NULL );
	
	if ( dwOp<sizeof(BODOC) ) {
		gv->dwErr = ERR_FILEREAD;
		fct->free( doc, gs );
		fct->free( de, gs );
		api->pCloseHandle( hEntrada );
		return false;
	}

	// Mover al final de los infos. Move to the end of infos.
	api->pSetFilePointer( hEntrada, (DWORD)doc->sig_estr, NULL, FILE_CURRENT );

	/////////////////////////////////////////////
	// 4. Preparar bufer de entrada
	//    Prepare input buffer.

	// leer nuestra estructura
	api->pReadFile( hEntrada, de, sizeof(BODOCEX), &dwOp, NULL );
	if ( dwOp<sizeof(BODOCEX) ) {
		// maybe we don't save this workspace
		gv->dwErr = ERR_ALLOCMEM;
		fct->free( doc, gs );
		fct->free( de, gs );
		api->pCloseHandle( hEntrada );
		return true;
	}

#ifdef _DEBUG
	if ( gs->Log ) gs->Log->AddStrf( gs, " >CliExtend: Number of Categories to load: %d.\r\n", de->nCats );
#endif

	nTam = sizeof(CAT_INFO)*de->nCats + sizeof(SRVINCAT)*de->nServerCat;
	pDatos = (BYTE *) fct->malloc( nTam, gs );
	if ( pDatos==NULL ) {
		gv->dwErr = ERR_ALLOCMEM;
		api->pCloseHandle( hEntrada );
		fct->free( doc, gs );
		fct->free( de, gs );
		return false;
	}

	/////////////////////////////////////////////
	// 5. Leer datos del archivo.
	//    Read file data.
	api->pReadFile( hEntrada, pDatos, nTam, &dwOp, NULL );
	if ( nTam!=dwOp ) {
		gv->dwErr = ERR_FILEREAD;
		fct->free( pDatos, gs );
		fct->free( doc, gs );
		fct->free( de, gs );
		api->pCloseHandle( hEntrada );
		return false;
	}

	/////////////////////////////////////////////
	// 6. Agregar Categorias
	//    Add Categories
	nPos=0;
	for (dwOp=0; dwOp<de->nCats; dwOp++)
	{
		tmp = (SRVCAT *) fct->malloc( sizeof(SRVCAT), gs );
		if ( tmp==NULL ) {
			gv->dwErr = ERR_ALLOCMEM;
			fct->free( pDatos, gs );
			fct->free( doc, gs );
			fct->free( de, gs );
			api->pCloseHandle( hEntrada );
			return false;
		}

		fct->memcpy( tmp->sNombre,  ((CAT_INFO *)(pDatos+nPos))->sNombre, sizeof(char)*65);
		tmp->bExpandido = ((CAT_INFO *)(pDatos+nPos))->bExpandido;
		api->pSendMessage( ctx->hSrvList, WM_ADDCATEGORY, (WPARAM) tmp, 0 );
		nPos +=sizeof(CAT_INFO);
	}

	/////////////////////////////////////////////
	// 7. Categorizar Servidores
	//    Categorize servers.
#ifdef _DEBUG
	if ( gs->Log ) gs->Log->AddStr( gs, " >CliExtend: Categorizing Servers.\r\n");
#endif

	for ( dwOp=0; dwOp<de->nServerCat; dwOp++ )
	{
		// Buscar Categoria
		nID = ((SRVINCAT *)(pDatos+nPos))->dwCatID;
		
		tmp = ctx->pcats;
		while ( tmp!=NULL ) {
			if ( tmp->nCRC==nID )
				break;
			tmp = tmp->sig;
		}
		if ( tmp==NULL ) 
			goto sig_ele;

		// Buscar servidor por categoria
		nID = ((SRVINCAT *)(pDatos+nPos))->dwSrvID;
		nfo = cli->pSrvList;
		while ( nfo!=NULL ) {
			if ( nfo->nCRC==nID )
				break;
			nfo = nfo->next;
		}
		if ( nfo==NULL )
			goto sig_ele;

		// categorizar
		api->pSendMessage( ctx->hSrvList, WM_CATEGORIZAR, (LPARAM)GetTreeItemByCtx(ctx->hList,(LPARAM)nfo), (LPARAM)tmp );

sig_ele:
		nPos+=sizeof(SRVINCAT);
	}

	
	/////////////////////////////////////////////
	// 8. Estado de las categorias
	//    Categories status.
	tmp = ctx->pcats;
	while ( tmp!=NULL ) 
	{
		// establecer estado.
		TreeView_Expand( ctx->hList, tmp->itm, (tmp->bExpandido)?TVE_EXPAND:TVE_COLLAPSE );
		tmp = tmp->sig;
	}

#ifdef _DEBUG
	if ( gs->Log ) gs->Log->AddStr( gs, " >CliExtend: Done.\r\n" );
#endif
	/////////////////////////////////////////////
	// 9. Salida
	//    Quit
	gv->dwErr = ERR_NO;
	fct->free( doc, gs );
	fct->free( de, gs );
	fct->free( pDatos, gs );
	api->pCloseHandle( hEntrada );
	return true;
}	


///////////////////////////////////////////////////////////////////////////
// FindSrvExDlg: Window procedure to handle the message for the Find Server dialog.
///////////////////////////////////////////////////////////////////////////
BOOL CALLBACK FindSrvExDlgProc ( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam ) 
{
	CLI *cli = ggs->cli;
	API *api = &(ggs->api);
	FCT *fct = &(ggs->fct);
	FSC2 *ctx= (FSC2 *) api->pGetWindowLong(hDlg,GWL_USERDATA);
	switch (uMsg) 
    { 
	// ----------------------------------------------------
	// Initailize Main Dialog -----------------------------
	case WM_INITDIALOG:
	{
		int idx;
		api->pSetWindowLong(hDlg,GWL_USERDATA,lParam);
		ctx = (FSC2 *) lParam;

		// Hacer botones planos
		// do flat buttons
		cli->pDoFlatBtn( ggs, api->pGetDlgItem( hDlg,IDC_FIND ) );
		cli->pDoFlatBtn( ggs, api->pGetDlgItem( hDlg,IDCANCEL ) );

		api->pSetWindowText( hDlg, cli->str.sFStitle );
		api->pSetDlgItemText( hDlg, IDC_SCAT , g_Ctx->str.sSLlblcat );
		api->pSetDlgItemText( hDlg, IDC_FIND    , cli->str.sFSbtnfindnext );
		api->pSetDlgItemText( hDlg, IDCANCEL    , cli->str.sFSbtncancel   );
		api->pSetDlgItemText( hDlg, IDC_SSRVNAME, cli->str.sFSlblsrvname  );
		api->pSetDlgItemText( hDlg, IDC_SSRVDIR , cli->str.sFSlblsrvdir   );

		// agregar categorias al combo box
		// Add categories to combo box
		HWND hCombo = api->pGetDlgItem( hDlg, IDC_SELCAT );
		SRVCAT *pcat = g_Ctx->slctx->pcats;
		api->pSendMessage( hCombo, CB_ADDSTRING, 0, (LPARAM) g_Ctx->str.sFSallcats );

		while ( pcat!=NULL ) {
			idx = api->pSendMessage( hCombo, CB_ADDSTRING  , 0, (LPARAM) pcat->sNombre );	
			api->pSendMessage( hCombo, CB_SETITEMDATA, idx, (LPARAM) pcat );
			pcat = pcat->sig;
		}
		api->pSendMessage( hCombo, CB_SETCURSEL, 0, 0 );
		
	#ifdef _LOGGING_
		if (ggs->Log) ggs->Log->AddStr( ggs, " >CliExtend: Find Server Ex dialog created.\r\n");
	#endif

		return TRUE;
	} // case WM_INITDIALOG

	// ----------------------------------------------------
	// Command Messages -----------------------------------
	case WM_COMMAND:
	{
		switch (LOWORD(wParam)) 
		{
			// Find Next server.
			// Buscar siguiente servidor.
			case IDC_FIND:
			{
				HWND	hTree = g_Ctx->slctx->hList;		// TreeView server list control
				DWORD	dwCRCName,dwCRCAddr;				// Name and address CRC
				short	nCat=0;								// Selected category
				bool	bInName=false, bInAddr=false;		// found name?, found address?
				SRVCAT	*pcat;								// Category info.

				GetDlgItemText(hDlg,IDC_SRVNAME,ctx->sName,64);
				GetDlgItemText(hDlg,IDC_SRVDIR,ctx->sAddr,64);

				if ( *ctx->sName ) 
					dwCRCName = fct->CRC32_Checksum((DWORD *)ctx->sName,64);
				else
					dwCRCName = 0;

				if ( *ctx->sAddr )
					dwCRCAddr = fct->CRC32_Checksum((DWORD *)ctx->sAddr,64);
				else
					dwCRCAddr = 0;

				// * Cambi� el nombre o la direccion a buscar?
				// changed the name or address to search for?
				if ( ctx->dwCRCAddr!=dwCRCAddr || ctx->dwCRCName!=dwCRCName ) {
					ctx->pSelSrv = cli->pSrvList;
					ctx->dwCRCAddr=dwCRCAddr;
					ctx->dwCRCName=dwCRCName;
					SetDlgItemText(hDlg,IDC_SMSG,"");
				}

				// * Cambi� la categoria?
				// changed the category?
				nCat = (short) SendDlgItemMessage( hDlg,IDC_SELCAT,CB_GETCURSEL,0,0);
				if ( nCat!=ctx->nSelCat && nCat!=0 ) {
					pcat = (SRVCAT *) SendDlgItemMessage(hDlg,IDC_SELCAT,CB_GETITEMDATA,nCat,0);
					ctx->nSelCat = nCat;
					ctx->hSelSrv = TreeView_GetChild( hTree, pcat->itm );
					SetDlgItemText(hDlg,IDC_SMSG,"");
				}

				// Buscar en todas la categorias
				// Find in all categories.
				if ( nCat==0 ) 
				{
					while ( ctx->pSelSrv!=NULL ) {

						// Buscar nombre. Search name
						if ( fct->InString(ctx->pSelSrv->svName,ctx->sName)>=0 )
							bInName = true;
						else
							bInName = false;

						// Buscar direcci�n. Search address.
						if ( fct->InString(ctx->pSelSrv->svAddress,ctx->sAddr)>=0 )
							bInAddr = true;
						else
							bInAddr = false;

						if ( (dwCRCName!=0 && dwCRCAddr!=0) && (!bInName || !bInAddr) )
							goto nextsrv;

						if ( (dwCRCName!=0 && !bInName) || (dwCRCAddr!=0 && !bInAddr) )
							goto nextsrv;

						SendMessage(cli->pMFrmCtx->hSrvList,WM_SETSELECTSRV,(LPARAM)ctx->pSelSrv,0);
						ctx->pSelSrv = ctx->pSelSrv->next;
						SetFocus(cli->pMFrmCtx->srvlist->hList);
						return TRUE;

			nextsrv:
						ctx->pSelSrv = ctx->pSelSrv->next;
					} // while ( ctx->pSelSrv!=NULL )

					// no hay servidores para buscar
					// there aren't servers to search.
					if ( ctx->pSelSrv==NULL ) {
						SetDlgItemText(hDlg,IDC_SMSG,cli->str.sFSmsgendfile);
						ctx->pSelSrv = cli->pSrvList;
					}
				}

				// Buscar solo en una categoria
				// Find in one category.
				else {
					
					TVITEM Itm;
					SERVER_INFO *nfo;

					// Obtener el servidor
					// Get server
					Itm.mask = TVIF_PARAM;
					Itm.hItem=ctx->hSelSrv;

					while ( TreeView_GetItem(hTree,&Itm) )	
					{
						nfo = (SERVER_INFO *) Itm.lParam;

						// Buscar nombre. Search name.
						if ( fct->InString(nfo->svName,ctx->sName)>=0 )
							bInName = true;
						else
							bInName = false;

						// Buscar direcci�n. Search address.
						if ( fct->InString(nfo->svAddress,ctx->sAddr)>=0 )
							bInAddr = true;
						else
							bInAddr = false;

						if ( (dwCRCName!=0 && dwCRCAddr!=0) && (!bInName || !bInAddr) )
							goto sigsrv;

						if ( (dwCRCName!=0 && !bInName) || (dwCRCAddr!=0 && !bInAddr) )
							goto sigsrv;

						SendMessage(cli->pMFrmCtx->hSrvList,WM_SETSELECTSRV,(LPARAM)nfo,0);
						ctx->hSelSrv = TreeView_GetNextSibling(hTree,Itm.hItem);
						SetFocus(cli->pMFrmCtx->srvlist->hList);
						return TRUE;

			sigsrv:
						// siguiente servidor
						Itm.hItem=TreeView_GetNextSibling(hTree,Itm.hItem);

					} // while ( TreeView_GetItem(hTree,&Itm) )

					// no hay servidores para buscar
					// there aren't servers to search.
					if ( Itm.hItem==NULL ) {
						SetDlgItemText(hDlg,IDC_SMSG,cli->str.sFSmsgendfile);
						ctx->hSelSrv = TreeView_GetChild( hTree, pcat->itm );
					}

				} // else

				return TRUE;
			} // case IDC_FIND

			case IDOK:
			case IDCANCEL:
				ggs->api.pPostQuitMessage(1);
				return TRUE;
		}
		break;
	} // case WM_COMMAND

	// Support for flat buttons.
	case WM_DRAWITEM:
		ggs->api.pSendMessage( ((LPDRAWITEMSTRUCT) lParam)->hwndItem, uMsg, (WPARAM)cli->pMFrmCtx->hbrDlg, lParam);
		return TRUE;

	// Return the Dialog Face brush ---------------------------------------
	case WM_CTLCOLORSTATIC:
		SetTextColor( (HDC) wParam, cli->pMFrmCtx->hFontColor );
		SetBkMode( (HDC) wParam, TRANSPARENT );
		return (BOOL) cli->pMFrmCtx->hbrDlg;

	case WM_CTLCOLORDLG: 
		return (BOOL) cli->pMFrmCtx->hbrDlg;

	// ----------------------------------------------------
	// Delete and Clean up this Window --------------------
	case WM_DESTROY: 
	#ifdef _LOGGING_
		if (ggs->Log) ggs->Log->AddStr( ggs, " >CliExtend: Find Server Ex dialog destroyed.\r\n");
	#endif
		return TRUE; 
	}
	return FALSE;
}

///////////////////////////////////////////////////////////////////////////
// FindSrvExThread: Creates the FindServer dialog and handles his messages.
// Arguments:
// * pData: Pointer to the THREAD_INFO strucute used to identify this thread.
///////////////////////////////////////////////////////////////////////////
// FindSrvExThread: Crea el dialogo FindServer y maneja sus mensajes.
// Argumentos:
// * pData: Puntero a la estructura THREAD_INFO usada para identificar esta
//   hilera.
///////////////////////////////////////////////////////////////////////////
DWORD FindSrvExThread ( void *pData )
{
	TI  *ti = (TI *)pData;
	GS  *gs = ti->gs;
	FCT *fct = &gs->fct;
	API *api = &gs->api;
	CLI *cli = gs->cli;
	FSC2 *ctx= (FSC2 *) ti->pThreadCtx;
	MSG  msg;

	if (gs->Log) gs->Log->AddStr(gs, " >CliExtend: FindSrvExThread Entry\r\n");

	// Create FindServer dialog.
	// Crear dialogo FindServer.
	ctx->hDlg = gs->api.pCreateDialogParam( g_hInstance, MAKEINTRESOURCE(IDD_FINDSRVEX),ctx->hParent,FindSrvExDlgProc,(LPARAM) ctx);
	if ( ctx->hDlg==NULL ) {
		if (gs->Log) gs->Log->AddStr(gs, " *CliExtend: Couldn't create FindServerEx dialog.\r\n");
		fct->free(ctx,gs);
		return NULL;
	}

	// Primary Message Queue.----------------------------------------------
	// Cola de mensajes primaria.
	while( ti->bRunThread ) 
	{

		// Get one message.
		// Obtener un mensage
		if ( api->pGetMessage(&msg,NULL,0,0)!=0 ) {

			// Is a message for the Dialog?
			// Es un mensage para el dialogo
			if ( IsDialogMessage(ctx->hDlg, &msg ) )
				continue;

			api->pTranslateMessage( &msg );
			api->pDispatchMessage ( &msg );

		} else {
			// we've got one WM_QUIT message, move away...
			// tenemos un mensaje WM_QUIT, vamonos lejos..
			ti->bRunThread = false;
		}
	}


	// Salida

	if (gs->Log) gs->Log->AddStr(gs, " >CliExtend: FindSrvExThread Exit\r\n");

	api->pDestroyWindow( ctx->hDlg );
	fct->free( ctx, gs  );
	ti->bRunThread = false;
	api->pCloseHandle( ti->hThread );
	ti->hThread = NULL;
	ti->dwThreadID = 0;
	return 0x1;
}

///////////////////////////////////////////////////////////////////////////
// CreateFindSrvDlg: Creates a Find Server dialog that is a child dialog of hParent
// and starts a new thread to handle the dialog messages.
// Input:
// > *gs: Global Structure pointer.
// > hParent: Parent Window handler of the new Find Server dialog.
///////////////////////////////////////////////////////////////////////////
FINDSRV2_CTX * BOAPI CreateFindSrvDlg( GS *gs, HWND hParent )
{
	FCT *fct = &gs->fct;
	CLI *cli = gs->cli;
	API *api = &gs->api;
	FINDSRV2_CTX *ctx;
	
	if ( gs==NULL )	return NULL;

	ctx = (FINDSRV2_CTX *) fct->malloc( sizeof(FINDSRV2_CTX), gs );
	if ( ctx==NULL ) return NULL;

	ctx->hParent = hParent;
	if ( fct->AddThread( gs, FindSrvExThread, ctx, g_Ctx->str.sFndSrvthrdname )==NULL ) {
		api->pDestroyWindow( ctx->hDlg );
		fct->free( ctx, gs );
		return NULL;
	}

	return ctx;
}



SRVLIST_CTX * BOAPI CreateSrvLstExDlg( GS *gs, HWND hParent )
{
	if ( gs==NULL )	return NULL;

	FCT *fct = &gs->fct;
	API *api = &gs->api;
	SRVLST2_CTX *ctx;
	HWND hDlg;

	ctx = (SRVLST2_CTX *) fct->malloc( sizeof(SRVLST2_CTX), gs );
	if ( ctx==NULL )
		return NULL;

	ctx->wndheight = 140;
	ctx->bShowDetails = true;
	hDlg = api->pCreateDialogParam( g_hInstance, MAKEINTRESOURCE(IDD_SRVLST), hParent, ServerListExProc, (LONG) ctx );

	if ( hDlg==NULL ) {
		fct->free( ctx, gs );
		return NULL;
	}

	return (SLC *)ctx;
}


HTREEITEM BOAPI GetTreeItemByCtx(HWND hTree, LPARAM nfo)
{
	TVITEM Itm;

	Itm.mask = TVIF_PARAM;
	Itm.hItem=TreeView_GetChild( hTree, TreeView_GetRoot( hTree ) );

	// buscar en la raiz
	while (TreeView_GetItem(hTree,&Itm))
	{
		if(Itm.lParam==nfo)
			return Itm.hItem;
		
		// es una categoria
		if ( ((SRVCAT *)Itm.lParam)->c==1 ) {
			// buscar en los elementos dentro de esta categoria.
			TVITEM I;

			I.mask = TVIF_PARAM;
			I.hItem=TreeView_GetChild( hTree, Itm.hItem );

			while ( TreeView_GetItem(hTree,&I) )
			{
				if ( I.lParam==nfo )
					return I.hItem;

				I.hItem = TreeView_GetNextSibling(hTree,I.hItem);
			}

		}

		// siguiente categoria/elemento
		Itm.hItem=TreeView_GetNextSibling(hTree,Itm.hItem);
	}
	return NULL;
}

int CALLBACK SortTreeItemsProc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	FCT *fct = &ggs->fct;
	bool i1,i2;

	// Es una Categoria o un ServerInfo
	// Is a Category or a ServerInfo
	i1 = ((SRVCAT *)lParam1)->c==1? true: false;
	i2 = ((SRVCAT *)lParam2)->c==1? true: false;

	// Ahora comparar.
	// now compare.
	if ( i1==true && i2==false )
		return -1;

	else if ( i1==false && i2==true )
		return 1;

	else if (i1==true && i1==true) {
		SRVCAT *c1 = (SRVCAT *)lParam1;
		SRVCAT *c2 = (SRVCAT *)lParam2;

		return fct->strncmp(c1->sNombre,c2->sNombre,fct->strlen(c1->sNombre) );
	} else {
		SERVER_INFO *s1 = (SERVER_INFO *) lParam1;
		SERVER_INFO *s2 = (SERVER_INFO *) lParam2;
		return fct->strnicmp(s1->svName,s2->svName,fct->strlen(s1->svName));
	}
	return 0;
}

// Actualiza el valor CRC de la estructura SRVER_INFO.
bool UpdateSrvCRC( GS *gs, SERVER_INFO *nfo )
{
	FCT *fct = &gs->fct;
	DWORD nCRC;

	nCRC = fct->CRC32_Checksum( (DWORD *)nfo, SRVINFO_SIZE );
	if (nCRC!=nfo->nCRC) {
		nfo->nCRC = nCRC;
		return true;
	}
	return false;
}


BOOL CALLBACK CatchEnterProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg) {
	case WM_KEYDOWN:
		if(wParam==VK_RETURN) {
			SendMessage(GetParent(hwndDlg),WM_ENTERKEY,(LPARAM)hwndDlg,0);
			return TRUE;
		} else if ( wParam==VK_ESCAPE ) {
			SendMessage(GetParent(hwndDlg),WM_ESCKEY,(LPARAM)hwndDlg,0);
			return TRUE;
		}
	case WM_KEYUP:
		if(wParam==VK_RETURN) {
			return TRUE;
		}
	case WM_CHAR:
		if(wParam==13) {
			return TRUE;
		}
	}

	return CallWindowProc((WNDPROC)GetWindowLong(hwndDlg,GWL_USERDATA),hwndDlg,uMsg,wParam,lParam);
}




///////////////////////////////////////////////////////////////////////////
// CLI_ServerListProc: Dialog Procedure for handle the window messages for 
// the Server List window.
///////////////////////////////////////////////////////////////////////////
BOOL CALLBACK ServerListExProc (HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	FCT			*fct = &(ggs->fct);
	VARS		*gv  = &(ggs->gv);
	API			*api = &(ggs->api);
	CLI			*cli = (ggs->cli);
	SRVLST2_CTX *ctx = (SRVLST2_CTX *) api->pGetWindowLong(hDlg,GWL_USERDATA);
	SRVLST_STR	*str = &g_Ctx->str;
	switch (msg) 
    { 
	
	// Iniciar Server List ------------------------------------------------
	// Initailize Server List ---------------------------------------------
	case WM_INITDIALOG:
	{
		ctx = (SRVLST2_CTX *) lParam;
		g_Ctx->slctx = ctx;
		api->pSetWindowLong( hDlg, GWL_USERDATA, lParam);

		/////////////////////////////////////
		// 1. Llenar nuestro contexto.
		//    Fill our context
		ctx->hSrvList	= hDlg;
		ctx->hList		= api->pGetDlgItem( hDlg, IDC_SRVLST );
		ctx->hConnMach	= (HICON) api->pLoadImage( g_hInstance, MAKEINTRESOURCE(IDI_CONN ) , IMAGE_ICON, 32, 32, 0 );
		ctx->hEditMach	= (HICON) api->pLoadImage( g_hInstance, MAKEINTRESOURCE(IDI_CONF ) , IMAGE_ICON, 32, 32, 0 );
		ctx->hNewMach	= (HICON) api->pLoadImage( g_hInstance, MAKEINTRESOURCE(IDI_MAS  ) , IMAGE_ICON, 32, 32, 0 );
		ctx->hDelMach	= (HICON) api->pLoadImage( g_hInstance, MAKEINTRESOURCE(IDI_MENOS) , IMAGE_ICON, 32, 32, 0 );
		ctx->hFindMach	= (HICON) api->pLoadImage( g_hInstance, MAKEINTRESOURCE(IDI_FIND ) , IMAGE_ICON, 32, 32, 0 );
		ctx->hCatAdd	= (HICON) api->pLoadImage( g_hInstance, MAKEINTRESOURCE(IDI_CATADD), IMAGE_ICON, 32, 32, 0 );
		ctx->hCatDel	= (HICON) api->pLoadImage( g_hInstance, MAKEINTRESOURCE(IDI_CATDEL), IMAGE_ICON, 32, 32, 0 );
		ctx->hCatEdit	= (HICON) api->pLoadImage( g_hInstance, MAKEINTRESOURCE(IDI_CATEDIT),IMAGE_ICON, 32, 32, 0 );
		ctx->hMenuCtx	= LoadMenu(g_hInstance,MAKEINTRESOURCE(IDR_CTX));

		/////////////////////////////////////
		// 2. Imagenes de los botones.
		//    Buttons' images.
		SendDlgItemMessage( hDlg, IDC_CONNECTMACHINE,BM_SETIMAGE,IMAGE_ICON,(LPARAM)ctx->hConnMach);
		SendDlgItemMessage( hDlg, IDC_DELETEMACHINE, BM_SETIMAGE,IMAGE_ICON,(LPARAM)ctx->hDelMach );
		SendDlgItemMessage( hDlg, IDC_EDITMACHINE,   BM_SETIMAGE,IMAGE_ICON,(LPARAM)ctx->hEditMach);
		SendDlgItemMessage( hDlg, IDC_NEWMACHINE,    BM_SETIMAGE,IMAGE_ICON,(LPARAM)ctx->hNewMach );
		SendDlgItemMessage( hDlg, IDC_FINDMACHINE,   BM_SETIMAGE,IMAGE_ICON,(LPARAM)ctx->hFindMach);
		SendDlgItemMessage( hDlg, IDC_CATADD    ,    BM_SETIMAGE,IMAGE_ICON,(LPARAM)ctx->hCatAdd  );
		SendDlgItemMessage( hDlg, IDC_CATDEL    ,    BM_SETIMAGE,IMAGE_ICON,(LPARAM)ctx->hCatDel  );
		SendDlgItemMessage( hDlg, IDC_CATEDIT   ,    BM_SETIMAGE,IMAGE_ICON,(LPARAM)ctx->hCatEdit );

		/////////////////////////////////////
		// 3. Botones planos.
		//    Flat buttons.
		cli->pDoFlatBtn( ggs, api->pGetDlgItem( hDlg, IDC_CONNECTMACHINE) );
		cli->pDoFlatBtn( ggs, api->pGetDlgItem( hDlg, IDC_DELETEMACHINE) );
		cli->pDoFlatBtn( ggs, api->pGetDlgItem( hDlg, IDC_EDITMACHINE ) );
		cli->pDoFlatBtn( ggs, api->pGetDlgItem( hDlg, IDC_NEWMACHINE  ) );
		cli->pDoFlatBtn( ggs, api->pGetDlgItem( hDlg, IDC_FINDMACHINE ) );
		cli->pDoFlatBtn( ggs, api->pGetDlgItem( hDlg, IDC_CATADD  ) );
		cli->pDoFlatBtn( ggs, api->pGetDlgItem( hDlg, IDC_CATDEL  ) );
		cli->pDoFlatBtn( ggs, api->pGetDlgItem( hDlg, IDC_CATEDIT ) );

		/////////////////////////////////////
		// 4. Cargar ImageList
		//    Load ImageList
		ctx->hImgLst = (HIMAGELIST) ImageList_LoadImage( g_hInstance,MAKEINTRESOURCE(IDB_SRVLIST),16,1,RGB(0,255,0),IMAGE_BITMAP, 0 );
		TreeView_SetImageList( ctx->hList, ctx->hImgLst, TVSIL_NORMAL  );
			
		/////////////////////////////////////
		// 5. Preparar controles
		//    Setup Controls
			
		// ListView
		TVINSERTSTRUCT tvi;
		tvi.hParent = TVI_ROOT;
		tvi.hInsertAfter = TVI_FIRST;
		tvi.item.mask = TVIF_IMAGE|TVIF_TEXT|TVIF_SELECTEDIMAGE;
		tvi.item.pszText = str->sSLtvroot;
		tvi.item.iImage = 2;
		tvi.item.iSelectedImage = 2;
		TreeView_InsertItem( ctx->hList, &tvi );

		// Strings (statics)
		api->pSendMessage( api->pGetDlgItem(hDlg,IDC_CAT), CB_ADDSTRING, 0, (LPARAM) str->sCatnone );
		api->pSendMessage(hDlg,WM_UPDATETEXT,0,0);

		// Agregar ToolTips
		// Add ToolTips.
		ctx->hToolTips = api->pCreateWindowEx(0, TOOLTIPS_CLASS, (LPSTR) NULL, TTS_ALWAYSTIP, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, hDlg, (HMENU) NULL, gv->hBaseAddress, NULL); 
		TOOLINFO ti;
		ti.cbSize = sizeof(TOOLINFO); 
		ti.uFlags = TTF_IDISHWND|TTF_SUBCLASS; 
		ti.hwnd = hDlg; 
		ti.uId = (UINT) api->pGetDlgItem(hDlg,IDC_NEWMACHINE); 
		ti.hinst = 0; 
		ti.lpszText = cli->str.sSLbtnnewsrv; 
		api->pSendMessage(ctx->hToolTips, TTM_ADDTOOL, 0, (LPARAM) &ti); 

		ti.uId = (UINT) api->pGetDlgItem(hDlg,IDC_EDITMACHINE);
		ti.lpszText = cli->str.sSLbtneditsrv;
		api->pSendMessage(ctx->hToolTips, TTM_ADDTOOL, 0, (LPARAM) &ti); 

		ti.uId = (UINT) api->pGetDlgItem(hDlg,IDC_DELETEMACHINE);
		ti.lpszText = cli->str.sSLbtndelsrv;
		api->pSendMessage(ctx->hToolTips, TTM_ADDTOOL, 0, (LPARAM) &ti); 

		ti.uId = (UINT) api->pGetDlgItem(hDlg,IDC_CONNECTMACHINE);
		ti.lpszText = cli->str.sSLbtnconsrv;
		api->pSendMessage(ctx->hToolTips, TTM_ADDTOOL, 0, (LPARAM) &ti); 

		ti.uId = (UINT) api->pGetDlgItem(hDlg,IDC_FINDMACHINE);
		ti.lpszText = cli->str.sSLbtnfindsrv;
		api->pSendMessage(ctx->hToolTips, TTM_ADDTOOL, 0, (LPARAM) &ti); 

		ti.uId = (UINT) api->pGetDlgItem(hDlg,IDC_CATADD);
		ti.lpszText = str->sSLttcatadd;
		api->pSendMessage(ctx->hToolTips, TTM_ADDTOOL, 0, (LPARAM) &ti); 

		ti.uId = (UINT) api->pGetDlgItem(hDlg,IDC_CATEDIT);
		ti.lpszText = str->sSLttcatedit;
		api->pSendMessage(ctx->hToolTips, TTM_ADDTOOL, 0, (LPARAM) &ti); 

		ti.uId = (UINT) api->pGetDlgItem(hDlg,IDC_CATDEL);
		ti.lpszText = str->sSLttcatdel;
		api->pSendMessage(ctx->hToolTips, TTM_ADDTOOL, 0, (LPARAM) &ti); 

		ti.uId = (UINT) api->pGetDlgItem(hDlg,IDC_NAME2);
		ti.lpszText = str->sSLttpressenter;
		api->pSendMessage(ctx->hToolTips, TTM_ADDTOOL, 0, (LPARAM) &ti); 

		ti.uId = (UINT) api->pGetDlgItem(hDlg,IDC_ADD);
		ti.lpszText = str->sSLttpressenter;
		api->pSendMessage(ctx->hToolTips, TTM_ADDTOOL, 0, (LPARAM) &ti); 

		/////////////////////////////////////
		// 6. Interceptar controles 'edit'.
		//    Subclass 'edit' controls
		HWND hLoc=api->pGetDlgItem(hDlg,IDC_NAME2);
		api->pSetWindowLong(hLoc,GWL_USERDATA,api->pGetWindowLong(hLoc,GWL_WNDPROC));
		api->pSetWindowLong(hLoc,GWL_WNDPROC,(LONG)CatchEnterProc);

		hLoc=api->pGetDlgItem(hDlg,IDC_ADD);
		api->pSetWindowLong(hLoc,GWL_USERDATA,api->pGetWindowLong(hLoc,GWL_WNDPROC));
		api->pSetWindowLong(hLoc,GWL_WNDPROC,(LONG)CatchEnterProc);

		hLoc=ctx->hList;
		api->pSetWindowLong(hLoc,GWL_USERDATA,api->pGetWindowLong(hLoc,GWL_WNDPROC));
		api->pSetWindowLong(hLoc,GWL_WNDPROC,(LONG)CatchEnterProc);


#ifdef _DEBUG
		if (ggs->Log) ggs->Log->AddStrf( ggs, " >CliExtend: Server List Dialog Created. Context address: %#x\r\n",ctx);
#endif
 		return TRUE;
	} // case WM_INITDIALOG

	// --------------------------------------------------------------------
	// If our size was changed, we need to adjust our controls.------------
	// Si nuestro tama�o es cambiado, necesitamos ajustar nuestros controles.
	case WM_WINDOWPOSCHANGED:
	{
		LPWINDOWPOS lpwp=(LPWINDOWPOS) lParam;
		if(( (lpwp->flags & SWP_NOSIZE)==0) || (api->pIsWindowVisible(hDlg)==FALSE) ) {
			ctx->wndheight = lpwp->cy;
			ctx->wndwidth = lpwp->cx;
			if ( ctx->bShowDetails==false ) {
				api->pSetWindowPos( ctx->hList, NULL, 37, 28, lpwp->cx-39, lpwp->cy-30,SWP_NOZORDER );
			} else {
				api->pSetWindowPos( ctx->hList, NULL, 37, 28, lpwp->cx-275, lpwp->cy-30,SWP_NOZORDER );
			}
			api->pSetWindowPos( api->pGetDlgItem(hDlg,IDC_SCAT) , NULL,lpwp->cx-220,25 ,100,15,SWP_NOZORDER );
			api->pSetWindowPos( api->pGetDlgItem(hDlg,IDC_CAT)  , NULL,lpwp->cx-220,40 ,100,15,SWP_NOZORDER );
					
			api->pSetWindowPos( api->pGetDlgItem(hDlg,IDC_CATADD) ,NULL,lpwp->cx-313,5 ,25,23,SWP_NOZORDER );
			api->pSetWindowPos( api->pGetDlgItem(hDlg,IDC_CATEDIT),NULL,lpwp->cx-288,5 ,25,23,SWP_NOZORDER );
			api->pSetWindowPos( api->pGetDlgItem(hDlg,IDC_CATDEL) ,NULL,lpwp->cx-263,5 ,25,23,SWP_NOZORDER );

			api->pSetWindowPos( api->pGetDlgItem(hDlg,IDC_SNAME2),NULL,lpwp->cx-220,65 ,100,15,SWP_NOZORDER );
			api->pSetWindowPos( api->pGetDlgItem(hDlg,IDC_NAME2) ,NULL,lpwp->cx-220,80 ,100,18,SWP_NOZORDER );
			api->pSetWindowPos( api->pGetDlgItem(hDlg,IDC_SADD) , NULL,lpwp->cx-220,105,100,15,SWP_NOZORDER );
			api->pSetWindowPos( api->pGetDlgItem(hDlg,IDC_ADD)   ,NULL,lpwp->cx-220,120,100,18,SWP_NOZORDER );

			api->pSetWindowPos( api->pGetDlgItem(hDlg,IDC_SENC2), NULL,lpwp->cx - 103,25 ,90,15,SWP_NOZORDER );
			api->pSetWindowPos( api->pGetDlgItem(hDlg,IDC_ENC)  , NULL,lpwp->cx - 103,40 ,90,15,SWP_NOZORDER );
			api->pSetWindowPos( api->pGetDlgItem(hDlg,IDC_SIO2) , NULL,lpwp->cx - 103,65 ,90,15,SWP_NOZORDER );
			api->pSetWindowPos( api->pGetDlgItem(hDlg,IDC_IO)   , NULL,lpwp->cx - 103,80 ,90,15,SWP_NOZORDER );
			api->pSetWindowPos( api->pGetDlgItem(hDlg,IDC_SAUTH2),NULL,lpwp->cx - 103,105,90,15,SWP_NOZORDER );
			api->pSetWindowPos( api->pGetDlgItem(hDlg,IDC_AUTH)  ,NULL,lpwp->cx - 103,120,90,15,SWP_NOZORDER );
				
			InvalidateRect( hDlg, NULL, TRUE );
			return 0;
		}
		break;
	} // case WM_WINDOWPOSCHANGED

	// --------------------------------------------------------------------
	// Command Messages ---------------------------------------------------
	case WM_COMMAND:
		{
			switch ( LOWORD(wParam) )
			{
				case IDOK:
					api->pSendMessage(hDlg,WM_ENTERKEY,(LPARAM)GetFocus(),0);
					return TRUE;

				case IDCANCEL:
					api->pSendMessage(hDlg,WM_ESCKEY,(LPARAM)GetFocus(),0);
					return TRUE;
				
				// Mostrar el Dialogo Nueva/Editar Configuracion del servidor
				// Show the New/Edit Server Settings ----------------------
				case IDM_NEWSRV:
				case IDC_NEWMACHINE: 
				{
					SERVER_INFO *nfo = (SERVER_INFO *) fct->malloc( sizeof(SERVER_INFO), ggs );
					if ( nfo==NULL )
						return TRUE;

					// mostrar el dialogo
					// show the dialog
					cli->pShowEditSrvDlg(ggs,hDlg,nfo);
					if (nfo->svAddress==NULL || *nfo->svAddress==0)  {
						fct->free(nfo,ggs);
						cli->pSetStatusText( ggs, cli->str.sStatusReady );
						return TRUE;
					}

					// agregar a la lista de servidores
					// add to serverlist.
					if ( cli->pSrvList == NULL )
						cli->pSrvList = nfo;
					else {
						SERVER_INFO *pSrv = cli->pSrvList;
						while (pSrv->next!=NULL)
							pSrv=pSrv->next;
						pSrv->next=nfo;
					}
					cli->bSave = true;
					api->pSendMessage( hDlg, WM_ADDSRV, (WPARAM)nfo, 0 );
#ifdef _LOGGING_
					if (ggs->Log) ggs->Log->AddStrf( ggs, " New Server Added: \"%s\" (%#x)\r\n",nfo->svAddress,(DWORD) nfo );
#endif
					cli->pSetStatusText( ggs, cli->str.sSBsrvnew );
					return TRUE;
				} // case IDC_NEWMACHINE

				// Mostrar Detalles ---------------------------------------
				// Show Details -------------------------------------------
				case IDC_SHOW:
				{ 
					if ( IsDlgButtonChecked(hDlg,IDC_SHOW)==BST_CHECKED ) {
						api->pSetWindowPos( ctx->hList, NULL, 37, 28, ctx->wndwidth-275, ctx->wndheight-30,SWP_NOZORDER|SWP_NOREPOSITION);
						ctx->bShowDetails = true;
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_SCAT) , SW_SHOW );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_CAT)  , SW_SHOW );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_SENC2), SW_SHOW );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_ENC)  , SW_SHOW );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_SIO2) , SW_SHOW );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_IO )  , SW_SHOW );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_SAUTH2),SW_SHOW );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_AUTH ) ,SW_SHOW );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_SNAME2),SW_SHOW );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_NAME2), SW_SHOW );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_SADD)  ,SW_SHOW );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_ADD)   ,SW_SHOW );
					} else {
						api->pSetWindowPos( ctx->hList, NULL, 37, 28, ctx->wndwidth-39, ctx->wndheight-30,SWP_NOZORDER|SWP_NOREPOSITION );
						ctx->bShowDetails = false;
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_SCAT) , SW_HIDE );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_CAT)  , SW_HIDE );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_SENC2), SW_HIDE );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_ENC)  , SW_HIDE );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_SIO2) , SW_HIDE );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_IO )  , SW_HIDE );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_SAUTH2),SW_HIDE );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_AUTH ) ,SW_HIDE );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_SNAME2),SW_HIDE );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_NAME2) ,SW_HIDE );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_SADD)  ,SW_HIDE );
						api->pShowWindow( api->pGetDlgItem(hDlg,IDC_ADD)   ,SW_HIDE );
					}
					cli->pSetStatusText( ggs, cli->str.sStatusReady );
					return TRUE;
				} // case IDC_SHOW

				// Borrar Servidor ----------------------------------------
				// Delete Server ------------------------------------------
				case IDMC_DELETESRV:
					TreeView_Select(ctx->hList,ctx->hDragItem,TVGN_CARET);
				case IDC_DELETEMACHINE:
				{
					TVITEM Itm;

					// Elemento seleccionado.
					// Get the selected item.
					Itm.hItem = TreeView_GetSelection( ctx->hList );
					if ( Itm.hItem==NULL )
						return TRUE;

					// Obtener el contexto del elemento
					// Get item context pointer
					Itm.mask = TVIF_PARAM;
					TreeView_GetItem( ctx->hList, &Itm );

					// Obtener la informacion del servidor.
					// Get server info.
					SERVER_INFO *nfo = (SERVER_INFO *) Itm.lParam;
					if ( nfo==NULL || ((SRVCAT *)Itm.lParam)->c==1 ) {
						cli->pSetStatusText( ggs, cli->str.sStatusReady );
						return TRUE;
					}

					// Tiene un ServerDlg?
					// Have a ServerDlg?
					if ( nfo->ctx!=NULL )
						api->pDestroyWindow( nfo->hWnd );

					// Quitar de la lista de servidores.
					// Remove from server list.
					if ( cli->pSrvList==nfo )
						cli->pSrvList=nfo->next;
					else {
						SERVER_INFO *pSrv = cli->pSrvList;
						while (pSrv!=NULL) {
							if (pSrv->next==nfo) {
								pSrv->next=nfo->next;
								break;
							}
							pSrv=pSrv->next;
						}
					}
#ifdef _DEBUG
					if (ggs->Log) ggs->Log->AddStrf( ggs, " >CliExtend: Server Deleted: \"%s\" (%#x)\r\n",nfo->svAddress,(DWORD)nfo );
#endif
					cli->bSave = true;
					fct->free( nfo,ggs );
					TreeView_DeleteItem( ctx->hList, Itm.hItem );
					cli->pSetStatusText( ggs, cli->str.sSBsrvdel );
					return TRUE;
				} // case IDC_DELETEMACHINE

				// Editar configuration del Servidor ----------------------
				// Edit Server Settings -----------------------------------
				case IDMC_EDITSRV:
					TreeView_Select(ctx->hList,ctx->hDragItem,TVGN_CARET);
				case IDC_EDITMACHINE:
				{
					TVITEM Itm;

					// Get the selected item
					Itm.hItem = TreeView_GetSelection( ctx->hList );
					if ( Itm.hItem==NULL )
						return TRUE;

					// Get item context pointer
					Itm.mask = TVIF_PARAM;
					TreeView_GetItem( ctx->hList, &Itm );

					// Get server info.
					SERVER_INFO *nfo = (SERVER_INFO *) Itm.lParam;
					if ( nfo==NULL || ((SRVCAT *)Itm.lParam)->c==1 ) {
						cli->pSetStatusText( ggs, cli->str.sStatusReady );
						return TRUE;
					}

					if (nfo->bConnected==true) {
						api->pMessageBox( hDlg, cli->str.sSDerredit, cli->str.sSDtitle, MB_ICONWARNING|MB_OK|MB_TOPMOST|MB_SETFOREGROUND);
						cli->pSetStatusText( ggs, cli->str.sStatusReady );
						return TRUE;
					}

					// Show the Dialog
					if ( cli->pShowEditSrvDlg(ggs,hDlg,nfo) ) {
						cli->bSave = true;
						
						// update list
						api->pSendMessage(hDlg,WM_UPDATESRV,(WPARAM)nfo,0);
						cli->pSetStatusText( ggs, cli->str.sSBsrvedit );
						return TRUE;
					}

					cli->pSetStatusText( ggs, cli->str.sStatusReady );
					return TRUE;
					
				} // case IDC_EDITMACHINE

				// Conectar a la maquina servidor -------------------------
				// Connect to server machine ------------------------------
				case IDMC_CONNECT:
					TreeView_Select(ctx->hList,ctx->hDragItem,TVGN_CARET);
				case IDC_CONNECTMACHINE:
				{
					SERVER_INFO *nfo;
					TVITEM Itm;

					// Get the selected item
					Itm.hItem = TreeView_GetSelection( ctx->hList );
					if ( Itm.hItem==NULL )
						return TRUE;

					// Get item context pointer
					Itm.mask = TVIF_PARAM;
					TreeView_GetItem( ctx->hList, &Itm );

					// Get server info.
					nfo = (SERVER_INFO *) Itm.lParam;
					if ( nfo==NULL || ((SRVCAT *)Itm.lParam)->c==1 )
						return TRUE;

					// Already have a window created.
					if ( nfo->ctx!=NULL ) {
						api->pShowWindow( nfo->hWnd, SW_SHOW );
						
					} else {

						// Create Dialog Box and keep all our data.
						cli->pCreateSrvDlg( ggs, hDlg, nfo );
					}

					cli->pSetStatusText( ggs, cli->str.sStatusReady );
					return TRUE;
				} // case IDC_CONNECTMACHINE

				// Desconectar servidor -----------------------------------
				case IDMC_DISCONNECT:
				{
					TVITEM tvi;
					SERVER_INFO *nfo;
					tvi.mask = TVIF_PARAM;
					tvi.hItem = ctx->hDragItem;

					TreeView_Select(ctx->hList,ctx->hDragItem,TVGN_CARET);
					TreeView_GetItem(ctx->hList, &tvi );

					nfo = (SERVER_INFO *) tvi.lParam;
					if ( nfo==NULL || nfo->ctx==NULL )
						return TRUE;

					api->pSendMessage( nfo->ctx->hDlg, WM_COMMAND, IDC_CONNECT, 0 );
					return TRUE;
				}

				// Buscar Servidor ----------------------------------------
				// Find Server --------------------------------------------
				case IDC_FINDMACHINE:
				{
					CreateFindSrvDlg(ggs,cli->hMainWnd);
					return TRUE;
				}

				// Agregar Categoria --------------------------------------
				// Add Category -------------------------------------------
				case IDC_CATADD:
				{
					SRVCAT *pcat = (SRVCAT *) fct->malloc(sizeof(SRVCAT),ggs);
					api->pDialogBoxParam(g_hInstance,MAKEINTRESOURCE(IDD_CATEGORYADD),hDlg,CategoryAddDlgProc, (LPARAM) pcat->sNombre );
					
					if ( *pcat->sNombre!=0 )
					{
						api->pSendMessage( hDlg, WM_ADDCATEGORY, (WPARAM)pcat, 0 );
						cli->bSave = true;
						cli->pSetStatusText( ggs, str->sSBcatadd );
						return TRUE;
					}
					cli->pSetStatusText( ggs, cli->str.sStatusReady );
					fct->free( pcat,ggs );
					return TRUE;
				} // case IDC_CATADD

				// Editar Categoria ---------------------------------------
				// Edit Category ------------------------------------------
				case IDMC_EDITCAT:
					TreeView_Select(ctx->hList,ctx->hDragItem,TVGN_CARET);
				case IDC_CATEDIT:
				{
					TVITEM	Itm;
					SRVCAT	*pcat;
					int		nCBItem;
					DWORD	nCRC;

					// obtener el elemento seleccionado.
					// Get the selected item
					Itm.hItem = TreeView_GetSelection( ctx->hList );
					if ( Itm.hItem==NULL )
						return TRUE;

					// Obtener la clase de elemento
					// Get item type
					Itm.mask = TVIF_IMAGE|TVIF_PARAM;
					TreeView_GetItem( ctx->hList, &Itm );

					if ( Itm.iImage==3 ) {

						pcat = (SRVCAT *) Itm.lParam;
						nCBItem = SendDlgItemMessage( hDlg, IDC_CAT, CB_FINDSTRING, 0, (LPARAM) pcat->sNombre );
						SendDlgItemMessage( hDlg, IDC_CAT, CB_DELETESTRING , nCBItem, 0 );

						api->pDialogBoxParam(g_hInstance,MAKEINTRESOURCE(IDD_CATEGORYADD),hDlg,CategoryAddDlgProc, (LPARAM) pcat->sNombre );
						
						nCRC = fct->CRC32_Checksum( (DWORD *)pcat->sNombre, 65 );

						if ( nCRC!=pcat->nCRC ) {
							cli->bSave = true;
							pcat->nCRC = nCRC;
							api->pSendMessage( hDlg, WM_EDITCATEGORY, (WPARAM) pcat, 0 );
							cli->pSetStatusText( ggs, str->sSBcatedit );
							return TRUE;
						}
					}
					cli->pSetStatusText( ggs, cli->str.sStatusReady );
					return TRUE;

				} // case IDC_CATEDIT

				// Borrar Categoria ---------------------------------------
				// Remove Category ----------------------------------------
				case IDMC_DELCAT:
					TreeView_Select(ctx->hList,ctx->hDragItem,TVGN_CARET);
				case IDC_CATDEL: 
				{
					TVITEM Itm;

					// obtener el elemento seleccionado.
					// Get the selected item
					Itm.hItem = TreeView_GetSelection( ctx->hList );
					if ( Itm.hItem==NULL )
						return TRUE;

					// Obtener la clase de elemento
					// Get item type
					Itm.mask = TVIF_IMAGE|TVIF_PARAM;
					TreeView_GetItem( ctx->hList, &Itm );

					if ( Itm.iImage==3 ) {
						api->pSendMessage( hDlg, WM_DELCATEGORY, Itm.lParam, 0 );
						cli->bSave = true;
						cli->pSetStatusText( ggs, str->sSBcatdel );
						return TRUE;
					}

					cli->pSetStatusText( ggs, cli->str.sStatusReady );
					return TRUE;

				} // case IDC_CATDEL

				// Notificaciones del control ComboBox
				// ComboBox notify messages
				case IDC_CAT:
				{
					if ( HIWORD(wParam)==CBN_SELCHANGE ) 
					{
						int n;

						n = SendDlgItemMessage( hDlg, IDC_CAT, CB_GETCURSEL,0,0);
						if ( api->pSendMessage( hDlg, WM_CATEGORIZAR, (LPARAM)TreeView_GetSelection(ctx->hList), SendDlgItemMessage(hDlg,IDC_CAT,CB_GETITEMDATA,n,0) ) ) {
							cli->bSave = true;
							cli->pSetStatusText( ggs, str->sSBsrvcat );
							return TRUE;
						}
						cli->pSetStatusText( ggs, cli->str.sStatusReady );
						return TRUE;
					}
					return FALSE;
				} // case IDC_CAT

				case IDC_ENC:
				{
					if ( HIWORD(wParam)==CBN_SELCHANGE ) 
					{
						// Si el elemento actual es un servidor, cambiar su
						// modulo de encryptaci�n por el seleccionado.
						int n;
						TVITEM tvi;
						SERVER_INFO *nfo;

						tvi.mask = TVIF_PARAM;
						tvi.hItem = TreeView_GetSelection( ctx->hList );
						TreeView_GetItem( ctx->hList, &tvi );

						if ( tvi.lParam==NULL || ((SRVCAT *)tvi.lParam)->c==1 )
							return TRUE;
					
						nfo = (SERVER_INFO *)tvi.lParam;
						n = SendDlgItemMessage( hDlg, IDC_ENC, CB_GETCURSEL,0,0);
						SendDlgItemMessage( hDlg, IDC_ENC, CB_GETLBTEXT, n ,(LPARAM) nfo->svEncryption );

						if ( UpdateSrvCRC(ggs,nfo) ) {
							cli->bSave = true;
							cli->pSetStatusText( ggs, cli->str.sSBsrvedit );
						}
						return TRUE;
					}
					return FALSE;
				} // case IDC_ENC

				case IDC_IO:
				{
					if ( HIWORD(wParam)==CBN_SELCHANGE ) 
					{
						// Si el elemento actual es un servidor, cambiar su
						// modulo de Comunicaci�n por el seleccionado.
						int n;
						TVITEM tvi;
						SERVER_INFO *nfo;

						tvi.mask = TVIF_PARAM;
						tvi.hItem = TreeView_GetSelection( ctx->hList );
						TreeView_GetItem( ctx->hList, &tvi );

						if ( tvi.lParam==NULL || ((SRVCAT *)tvi.lParam)->c==1 )
							return TRUE;
					
						nfo = (SERVER_INFO *)tvi.lParam;
						n = SendDlgItemMessage( hDlg, IDC_IO, CB_GETCURSEL,0,0);
						SendDlgItemMessage( hDlg, IDC_IO, CB_GETLBTEXT, n ,(LPARAM) nfo->svConnectionType );

						if ( UpdateSrvCRC(ggs,nfo) ) {
							cli->bSave = true;
							cli->pSetStatusText( ggs, cli->str.sSBsrvedit );
						}
						return TRUE;
					}
					return FALSE;
				} // case IDC_IO 

				case IDC_AUTH:
				{
					if ( HIWORD(wParam)==CBN_SELCHANGE ) 
					{
						// Si el elemento actual es un servidor, cambiar su
						// modulo de autenticaci�n por el seleccionado.
						int n;
						TVITEM tvi;
						SERVER_INFO *nfo;

						tvi.mask = TVIF_PARAM;
						tvi.hItem = TreeView_GetSelection( ctx->hList );
						TreeView_GetItem( ctx->hList, &tvi );

						if ( tvi.lParam==NULL || ((SRVCAT *)tvi.lParam)->c==1 )
							return TRUE;
					
						nfo = (SERVER_INFO *)tvi.lParam;
						n = SendDlgItemMessage( hDlg, IDC_AUTH, CB_GETCURSEL,0,0);
						SendDlgItemMessage( hDlg, IDC_AUTH, CB_GETLBTEXT, n ,(LPARAM) nfo->svAuthentication );

						if ( UpdateSrvCRC(ggs,nfo) ) {
							cli->bSave = true;
							cli->pSetStatusText( ggs, cli->str.sSBsrvedit );
						}
						return TRUE;
					}
					return FALSE;
				}// case IDC_AUTH
			
			} // switch ( LOWORD(wParam) )

			return FALSE;
		} // case WM_COMMAND

	// Mensajes de notificaci�n -------------------------------------------
	// Notify messages.----------------------------------------------------
	case WM_NOTIFY:
	{
		switch (((LPNMHDR) lParam)->code)
		{
			// Inicio del Proceso Arrastra y soltar.
			// Start-up Drag and drop process
			case TVN_BEGINDRAG:
			{
				LPNMTREEVIEW lpnmtv = (LPNMTREEVIEW) lParam;
				HIMAGELIST himl;
				TVITEM itm;

				itm.mask = TVIF_PARAM;
				itm.hItem = lpnmtv->itemNew.hItem;
				TreeView_GetItem( ctx->hList, &itm );

				if ( itm.lParam==NULL || ((SRVCAT *)itm.lParam)->c==1 )
					return TRUE;
				
				// Decir al control TreeView crear una imagen para usar en el arrastre.
				// Tell the TreeView control create an image to use for dragging. 
				himl = TreeView_CreateDragImage(ctx->hList, lpnmtv->itemNew.hItem); 
 
				// Inicar operacion de arrastre
				// Start the drag operation. 
				ImageList_BeginDrag(himl, 0, 1, 1); 
				ScreenToClient(ctx->hList,&lpnmtv->ptDrag);
				ImageList_DragEnter(ctx->hList,lpnmtv->ptDrag.x,lpnmtv->ptDrag.y);
 
				// Direccionar entradas del mouse a la ventana padre.
				// Direct mouse input to the parent window. 
				SetCapture(hDlg); 
				ctx->hDragItem = lpnmtv->itemNew.hItem;
				ctx->bDrag = true;
#ifdef _DEBUG
				if ( ggs->Log ) ggs->Log->AddStr( ggs, " >CliExtend: Dragging TreeView Item.\r\n" );
#endif
				return TRUE;
			}

			// Una ventana fue presionada en el control TreeView.
			// a key was pressed in the TreeView Control.
			case TVN_KEYDOWN :
			{
				LPNMTVKEYDOWN pnkd = (LPNMTVKEYDOWN) lParam;
				switch (pnkd->wVKey)
				{
					case VK_DELETE:
						api->pSendMessage(hDlg,WM_COMMAND,IDC_DELETEMACHINE,0);
						break;
					case VK_ESCAPE:
						api->pSendMessage( hDlg, WM_ESCKEY, (LPARAM)pnkd->hdr.hwndFrom,0 );
						break;
				}
				return TRUE;
			}

			case NM_DBLCLK:
			case NM_RETURN:
				api->pSendMessage(hDlg,WM_COMMAND,IDC_CONNECTMACHINE,0);
				return TRUE;

			// Selection cambiada en el control TreeView.
			// Selection changed in TreeView control.
			case TVN_SELCHANGED:
			{
				if ( ctx->bShowDetails==false )
					return TRUE;

				LPNMTREEVIEW pnmtv = (LPNMTREEVIEW) lParam;
				TVITEM itm;
				itm.mask = TVIF_IMAGE;
				itm.hItem = pnmtv->itemNew.hItem;
				TreeView_GetItem(ctx->hList,&itm);

				// es categoria?
				if ( itm.iImage==3 ) {
					api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_NAME2), FALSE );
					api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_ADD  ), FALSE );
					api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_ENC  ), FALSE );
					api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_IO   ), FALSE );
					api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_AUTH ), FALSE );
					api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_CAT ), FALSE );
					return TRUE;
				}

				SERVER_INFO *nfo = (SERVER_INFO *) pnmtv->itemNew.lParam;
				if ( nfo!=NULL ) {

					// Si el servidor esta conectado, entonces no podemos cambiar la configuracion.
					// If the server is connected, then we can't change settings
					if ( nfo->bConnected ==true) {
						// Inhabilitar controles
						// Disable controls
						api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_NAME2), FALSE );
						api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_ADD  ), FALSE );
						api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_ENC  ), FALSE );
						api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_IO   ), FALSE );
						api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_AUTH ), FALSE );
					} else {
						// Habilitar Controles
						// Enable Controls.
						api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_NAME2), TRUE );
						api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_ADD  ), TRUE );
						api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_ENC  ), TRUE );
						api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_IO   ), TRUE );
						api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_AUTH ), TRUE );
					}

					api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_CAT ), TRUE );

					api->pSetDlgItemText(hDlg,IDC_NAME2,nfo->svName);
					api->pSetDlgItemText(hDlg,IDC_ADD  ,nfo->svAddress);

					// Buscar la categoria
					// Find out the category
					itm.mask = TVIF_PARAM;
					itm.hItem = TreeView_GetParent(ctx->hList, pnmtv->itemNew.hItem);
					TreeView_GetItem(ctx->hList,&itm);
					
					// only the root item have lParam==NULL
					if ( itm.lParam!=NULL ) {
						SRVCAT *pcat = (SRVCAT *)itm.lParam;
						SendDlgItemMessage(hDlg,IDC_CAT,CB_SELECTSTRING,-1,(LPARAM)pcat->sNombre);
					} else
						SendDlgItemMessage(hDlg,IDC_CAT,CB_SETCURSEL,0,0);					

					api->pSendMessage(hDlg,WM_UPDATEMODULES,0,0);
					SendDlgItemMessage(hDlg,IDC_ENC ,CB_SELECTSTRING,-1,(LPARAM)nfo->svEncryption);
					SendDlgItemMessage(hDlg,IDC_IO  ,CB_SELECTSTRING,-1,(LPARAM)nfo->svConnectionType);
					SendDlgItemMessage(hDlg,IDC_AUTH,CB_SELECTSTRING,-1,(LPARAM)nfo->svAuthentication);

				} else {
					api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_NAME2), FALSE );
					api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_ADD  ), FALSE );
					api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_ENC  ), FALSE );
					api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_IO   ), FALSE );
					api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_AUTH ), FALSE );
					api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_CAT ), FALSE );
				} // if ( nfo!=NULL )

				return TRUE;
			} // case TVN_SELCHANGED

			// Mostrar menu de contexto -----------------------------------
			case NM_RCLICK:
			{
				POINT pt;
				TVHITTESTINFO tvht;
				TVITEM tvi;
				HMENU hSubMenu;

				GetCursorPos(&pt);

				tvht.pt = pt;
				ScreenToClient(ctx->hList,&tvht.pt);
				tvht.hItem = NULL;
				tvht.flags = TVHT_ONITEM;
				ctx->hDragItem = TreeView_HitTest( ctx->hList,&tvht );

				if ( tvi.hItem = ctx->hDragItem ) {
					tvi.mask = TVIF_IMAGE;
					TreeView_GetItem( ctx->hList, &tvi );

					if ( tvi.iImage==0 ) {
						hSubMenu = GetSubMenu( ctx->hMenuCtx, 0 );
						EnableMenuItem(hSubMenu,IDMC_CONNECT,MF_ENABLED);
						EnableMenuItem(hSubMenu,IDMC_DISCONNECT,MF_GRAYED);
						TrackPopupMenu(hSubMenu,TPM_RIGHTBUTTON,pt.x,pt.y,0,hDlg,NULL);
					} else if ( tvi.iImage==1 ) {
						hSubMenu = GetSubMenu( ctx->hMenuCtx, 0 );
						EnableMenuItem(hSubMenu,IDMC_CONNECT,MF_GRAYED);
						EnableMenuItem(hSubMenu,IDMC_DISCONNECT,MF_ENABLED);
						TrackPopupMenu(hSubMenu,TPM_RIGHTBUTTON,pt.x,pt.y,0,hDlg,NULL);
					} else if ( tvi.iImage==2 ) {
						// none!
					} else if ( tvi.iImage==3 ) {
						hSubMenu = GetSubMenu( ctx->hMenuCtx, 1 );
						TrackPopupMenu(hSubMenu,TPM_RIGHTBUTTON,pt.x,pt.y,0,hDlg,NULL);
					}
				}
				return TRUE;
			} // case NM_RCLICK
			
		} // switch (((LPNMHDR) lParam)->code)
		break;
	} // case WM_NOTIFY

	// El mouse se movi�! -------------------------------------------------
	// Mouse moved! -------------------------------------------------------
	case WM_MOUSEMOVE:
	{
		HTREEITEM htiTarget;  // elemento objetivo
	    TVHITTESTINFO tvht;
		POINT pt;
 
		// Estamos en operacion arrastre?
		// We're dragging?
	    if ( ctx->bDrag ) { 

			// Obtener las cordenadas del mouse
			// get mouse coordinates
			GetCursorPos(&pt);
			ScreenToClient(ctx->hList,&pt);
 
			// Dibujar el elemento en la posicion actual del cursor
		    // Drag the item to the current position of the mouse cursor. 
			RedrawWindow(ctx->hList,NULL,NULL,RDW_INVALIDATE);
			ImageList_DragMove(pt.x, pt.y); 
			
			// Obtener is el cursor esta sobre un elemento. Si es as�, resaltar el elmento para soltar el objetivo.
		    // Find out if the cursor is on the item. If it is, highlight the item as a drop target. 
			tvht.pt.x = pt.x; 
			tvht.pt.y = pt.y; 
			tvht.flags = TVHT_ONITEM;
			if ((htiTarget = TreeView_HitTest(ctx->hList, &tvht)) != NULL) { 
				TreeView_SelectDropTarget(ctx->hList, htiTarget); 
				TreeView_EnsureVisible( ctx->hList, htiTarget );
			} 
			return TRUE;
		} 
		return FALSE;
	} // case WM_MOUSEMOVE

	// Boton del mouse soltado --------------------------------------------
	// Mouse button up ----------------------------------------------------
	case WM_LBUTTONUP:
	{
		if ( ctx->bDrag ) { 
			int res;
			HTREEITEM hPadre;
			TVITEM tvi;

			ImageList_DragLeave(ctx->hList);
			ImageList_EndDrag(); 

			tvi.mask = TVIF_PARAM;
			tvi.hItem = TreeView_GetDropHilight( ctx->hList );
			TreeView_GetItem( ctx->hList, &tvi );
			hPadre = TreeView_GetParent( ctx->hList, tvi.hItem );

			if ( tvi.lParam==NULL ) {
				// only root item have lParam=NULL.
				res = api->pSendMessage( hDlg, WM_CATEGORIZAR, (LPARAM)ctx->hDragItem, NULL );

			} else if ( ((SRVCAT *)tvi.lParam)->c==1 ) {
				// categoria
				res = api->pSendMessage( hDlg, WM_CATEGORIZAR, (LPARAM)ctx->hDragItem, tvi.lParam );

			} else {
				// Servidor
				tvi.hItem = hPadre;
				TreeView_GetItem( ctx->hList, &tvi );
				res = api->pSendMessage( hDlg, WM_CATEGORIZAR, (LPARAM)ctx->hDragItem, tvi.lParam );
			}

			if ( res ) {
				cli->bSave=true;
				cli->pSetStatusText( ggs, str->sSBsrvcat );
			} else 
				cli->pSetStatusText( ggs, cli->str.sStatusReady );

			TreeView_SelectDropTarget(ctx->hList, NULL); 
			ReleaseCapture(); 
			ctx->bDrag = false; 
#ifdef _DEBUG
			if ( ggs->Log ) ggs->Log->AddStr( ggs, " >CliExtend: Drop TreeView Item done.\r\n" );
#endif

		} 
		return FALSE;
	}

	// Soporte pata botones planos ----------------------------------------
	// Support for flat buttons.
	case WM_DRAWITEM:
		api->pSendMessage( ((LPDRAWITEMSTRUCT) lParam)->hwndItem, msg, (WPARAM)cli->pMFrmCtx->hbrDlg, lParam);
		return TRUE;

	// Ordenar la lista de servidores -------------------------------------
	// Sort the list of servers -------------------------------------------
	case WM_SORTLST:
	{
		TVSORTCB srt;
		srt.hParent = TreeView_GetRoot(ctx->hList);
		srt.lParam = 0;
		srt.lpfnCompare = SortTreeItemsProc;

		TreeView_SortChildrenCB( ctx->hList, &srt, 0 );
		return TRUE;
	}

	// Adds a new server to the list. -------------------------------------
	// Agrega un servidor a la lista.
	case WM_ADDSRV:
	{
			TVITEM tvi;
			TVINSERTSTRUCT tvins;

			SERVER_INFO *nfo = (SERVER_INFO *)wParam;

			// preparar texto
			// prepare text
			char svText[50];
			api->pwsprintf(svText,"%.20s [%.20s]",nfo->svName,nfo->svAddress);
			if ( nfo==NULL )
				return TRUE;
			
			// agregar a TreeView
			// add to TreeView
			tvi.mask = TVIF_TEXT|TVIF_IMAGE|TVIF_SELECTEDIMAGE|TVIF_PARAM;
			tvi.pszText = svText;
			tvi.lParam = (LPARAM) nfo;
			tvi.iImage = 0;
			tvi.iSelectedImage = 0;
			tvins.item = tvi;
			tvins.hInsertAfter = TVI_LAST;
			tvins.hParent = TreeView_GetRoot(ctx->hList);

			TreeView_InsertItem(ctx->hList,&tvins);
			TreeView_Expand(ctx->hList,TreeView_GetRoot(ctx->hList),TVE_EXPAND );
			api->pSendMessage( hDlg, WM_SORTLST, 0, 0 );
			InvalidateRgn(ctx->hList,NULL,TRUE);

	#ifdef _DEBUG
			if (ggs->Log) ggs->Log->AddStrf(ggs," >CliExtend: Server \"%s\" Added (%#x)\r\n",nfo->svAddress,nfo);
	#endif
			return TRUE;					
	} // case WM_ADDSRV
	
	// Update server info showed in the List control ----------------------
	// Actualizar informacion del servidor en la Lista.
	case WM_UPDATESRV:
	{
		SERVER_INFO *nfo = (SERVER_INFO*) wParam;
		if ( nfo==NULL )
			return TRUE;
		
		TVITEM Itm;
		char buf[75];
		api->pwsprintf(buf,"%.20s [%.20s]",nfo->svName,nfo->svAddress);

		Itm.mask = TVIF_TEXT|TVIF_STATE|TVIF_IMAGE|TVIF_SELECTEDIMAGE ;
		Itm.pszText = buf;
		Itm.stateMask = 255;
		if ( nfo->bConnected==true ) {
			Itm.state = TVIS_BOLD;
			Itm.iImage = Itm.iSelectedImage = 1;
		} else {
			Itm.state = 0;
			Itm.iImage = Itm.iSelectedImage = 0;
		}
		Itm.hItem=GetTreeItemByCtx(ctx->hList,(LPARAM)nfo);

		TreeView_SetItem(ctx->hList,&Itm);

		if ( TreeView_GetSelection(ctx->hList)==Itm.hItem && Itm.iImage==1 ) {
			api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_NAME2), FALSE );
			api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_ADD  ), FALSE );
			api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_ENC  ), FALSE );
			api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_IO   ), FALSE );
			api->pEnableWindow( api->pGetDlgItem(hDlg,IDC_AUTH ), FALSE );
		}

		// actualizar Server Dialog
		// update Server Dialog
		api->pwsprintf( buf,cli->str.sSDinfo ,nfo->svName,nfo->svAddress );
		api->pSetWindowText( api->pGetDlgItem( nfo->hWnd, IDC_SRVINFO),buf );
		
		api->pwsprintf( buf, "%s [%s]",cli->str.sSDtitle,nfo->svAddress );
		api->pSetWindowText( nfo->hWnd, buf );
		
		// Ordenar elementos
		// Sort Items
		api->pSendMessage( hDlg, WM_SORTLST, 0, 0 );
#ifdef _DEBUG
		if ( lParam!=1 ) {
			if (ggs->Log) ggs->Log->AddStrf(ggs," >CliExtend: Server Settings updated: \"%s\" (%#x)\r\n",nfo->svAddress,(DWORD)nfo);
		}
#endif
		return TRUE;
	} // case WM_UPDATESRV

	// Agregar Categoria --------------------------------------------------
	// Add Category -------------------------------------------------------
	case WM_ADDCATEGORY:
	{
		SRVCAT *tmp, *pcat = (SRVCAT *) wParam;
		if ( pcat==NULL )
			return TRUE;

		// agregar al TreeView
		TVITEM tvi;
		TVINSERTSTRUCT tvins;

		tvi.mask = TVIF_TEXT|TVIF_IMAGE|TVIF_SELECTEDIMAGE|TVIF_PARAM;
		tvi.pszText = pcat->sNombre;
		tvi.lParam = (LPARAM) pcat;
		tvi.iImage = 3;
		tvi.iSelectedImage = 3;
		tvins.item = tvi;
		tvins.hInsertAfter = TVI_FIRST;
		tvins.hParent = TreeView_GetRoot(ctx->hList);

		pcat->itm = TreeView_InsertItem(ctx->hList,&tvins);

		// agregar al Combo Box
		int n = SendDlgItemMessage( hDlg,IDC_CAT, CB_ADDSTRING, 0, (LPARAM) pcat->sNombre );
		SendDlgItemMessage( hDlg, IDC_CAT, CB_SETITEMDATA, n, (LPARAM) pcat );

		// agregar a la lista de categorias.
		pcat->c = 1; // (just a sign)
		pcat->nCRC = fct->CRC32_Checksum( (DWORD *)pcat->sNombre, 65 );
		if ( ctx->pcats==NULL )
			ctx->pcats = pcat;
		else {
			// buscar ultimo elemento.
			tmp = ctx->pcats;
			while ( tmp->sig!=NULL ) 
				tmp=tmp->sig;
			tmp->sig = pcat;
		}

		// Ordenar elementos
		// Sort Items
		api->pSendMessage( hDlg, WM_SORTLST, 0, 0 );

	#ifdef _DEBUG
		if (ggs->Log) ggs->Log->AddStrf( ggs, " >CliExtend: Category Added: %s.\r\n",pcat->sNombre);
	#endif
		return TRUE;
	} // case WM_ADDCATEGORY

	// Borrar Categoria ---------------------------------------------------
	// Delete Category ----------------------------------------------------
	case WM_DELCATEGORY:
	{
		HTREEITEM hi;
		SRVCAT *pcat = (SRVCAT *) wParam;
		int nCBItem;

		// tiene elementos hijos?
		// have children?
		hi = TreeView_GetChild( ctx->hList, pcat->itm );
		while ( hi!=NULL )
		{
			// mover elementos a la raiz
			// move items to root
			api->pSendMessage( hDlg, WM_CATEGORIZAR, (LPARAM)hi, NULL );
			hi = TreeView_GetChild( ctx->hList, pcat->itm );
		}

		// Borrar del ComboBox.
		// Remove from ComboBox.
		nCBItem = SendDlgItemMessage( hDlg, IDC_CAT, CB_FINDSTRING, 0, (LPARAM) pcat->sNombre );
		SendDlgItemMessage( hDlg, IDC_CAT, CB_DELETESTRING , nCBItem, 0 );

		// Borrar del TreeView.
		// Remove from TreeView.
		TreeView_DeleteItem( ctx->hList, (HTREEITEM) pcat->itm );

		// Borrar de la lista de categorias.
		// Remove from the list of categories.
		if ( ctx->pcats==pcat )
			ctx->pcats = pcat->sig;
		else {
			SRVCAT *tmp = ctx->pcats;
			while ( tmp!=NULL )
			{
				if ( tmp->sig==pcat ) {
					tmp->sig=pcat->sig;
					break;
				}
				tmp = tmp->sig;
			}
		}

	#ifdef _DEBUG
		if (ggs->Log) ggs->Log->AddStrf( ggs, " >CliExtend: Category Deleted: %s.\r\n",pcat->sNombre);
	#endif
		
		api->pSendMessage( hDlg, WM_SORTLST, 0, 0 );
		fct->free( pcat, ggs );
		cli->bSave = true;
		return TRUE;
	} // case WM_DELCATEGORY

	// Editar Categoria ---------------------------------------------------
	// Edit Category ------------------------------------------------------
	case WM_EDITCATEGORY:
	{
		TVITEM Itm;
		SRVCAT *pcat = (SRVCAT *) wParam;
		if ( pcat==NULL )
			return NULL;

		// actualizar TreeView
		Itm.hItem = pcat->itm;
		Itm.mask = TVIF_TEXT;
		Itm.pszText = pcat->sNombre;
		TreeView_SetItem(ctx->hList, &Itm);

		// actualizar ComboBox
		SendDlgItemMessage( hDlg, IDC_CAT, CB_ADDSTRING, 0, (LPARAM)pcat->sNombre );

		// Ordenar elementos
		// Sort Items
		api->pSendMessage( hDlg, WM_SORTLST, 0, 0 );
	#ifdef _DEBUG
		if (ggs->Log) ggs->Log->AddStrf( ggs, " >CliExtend: Category Edited: %s.\r\n",pcat->sNombre);
	#endif
		return TRUE;
	} // case WM_EDITCATEGORY

	// Categorizar servidor -----------------------------------------------
	case WM_CATEGORIZAR:
	{
		TVITEM tvi;
		TVINSERTSTRUCT tvins;
		SRVCAT *pcat = (SRVCAT *)lParam;
		char buf[75];

		if ( wParam==0 )
			return TRUE;

		// Obtener el elemento.
		// Get the item
		tvi.hItem = (HTREEITEM) wParam;

		// esta en la misma categoria... entonces no mover.
		// is in the same category... then don't move.
		if ( pcat!=NULL && (TreeView_GetParent(ctx->hList,tvi.hItem)==pcat->itm) ) 
			return TRUE;

		if ( pcat==NULL && (TreeView_GetParent(ctx->hList,tvi.hItem)==TreeView_GetRoot(ctx->hList)) )
			return TRUE;

		// obtener la info del elemento
		// Get item info
		tvi.mask = TVIF_PARAM|TVIF_IMAGE|TVIF_SELECTEDIMAGE|TVIF_TEXT;
		tvi.pszText = buf;
		tvi.cchTextMax = 74;
		TreeView_GetItem(ctx->hList,&tvi);
						
		// Quitar de la categoria actual
		// Remove from the current category.
		TreeView_DeleteItem(ctx->hList,tvi.hItem);

		// agregar a la nueva categoria
		// add to the new category.
		tvins.item = tvi;
		tvins.hInsertAfter = TVI_SORT;
		if ( pcat==NULL )
			tvins.hParent = TreeView_GetRoot(ctx->hList);
		else
			tvins.hParent = pcat->itm;

		TreeView_Select( ctx->hList, TreeView_InsertItem(ctx->hList,&tvins), TVGN_CARET );
		TreeView_Expand(ctx->hList,TreeView_GetRoot(ctx->hList),TVE_EXPAND );	
		api->pSendMessage( hDlg, WM_SORTLST, 0, 0 );
	#ifdef _DEBUG
		if (ggs->Log) ggs->Log->AddStrf( ggs, " >CliExtend: Server \"%s\" moved to %s.\r\n",((SERVER_INFO *)tvi.lParam)->svAddress,(pcat==NULL)?"root item":pcat->sNombre);
	#endif
	
		SetWindowLong(hDlg,DWL_MSGRESULT,1);
		return TRUE;
	} // case WM_CATEGORIZAR

	// Selects a server and does it visible in the list -------------------
	// Selecciona un servidor y lo hace visible en la lista. --------------
	case WM_SETSELECTSRV:
	{
		HTREEITEM hItem;

		if ( wParam==0 )
			return TRUE;

		hItem = GetTreeItemByCtx(ctx->hList,wParam);

		TreeView_EnsureVisible(ctx->hList,hItem);
		TreeView_SelectItem(ctx->hList,hItem);
		return TRUE;
	}

	// Returns the pointer to the server selected in the list. ------------
	// Devuelve el puntero al servidor seleccionado en la lista. ----------
	case WM_GETSELECTSRV:
	{
		TVITEM tvi;

		tvi.hItem	= TreeView_GetSelection( ctx->hList );
		if ( tvi.hItem==0 ) {
			SetWindowLong(hDlg,	DWL_MSGRESULT, 0);
			return TRUE;
		}

		tvi.mask	= TVIF_PARAM ;
		TreeView_GetItem( ctx->hList, &tvi );
		SetWindowLong(hDlg,	DWL_MSGRESULT, tvi.lParam);
		return TRUE;
	}


	// Erase all the server list. -----------------------------------------
	// Borrar toda lista de servidores ------------------------------------
	case WM_CLEARLST:
	{
		// Delete all items in the list
		HTREEITEM next,itm;
		
		itm=TreeView_GetChild( ctx->hList, TreeView_GetRoot( ctx->hList ) );
		while ( itm )
		{
			next=TreeView_GetNextSibling(ctx->hList,itm);
			TreeView_DeleteItem( ctx->hList, itm );
			itm=next;
		}
#ifdef _DEBUG
		if ( ggs->Log ) ggs->Log->AddStr( ggs, " >CliExtend: All list items deleted.\r\n" );
#endif

		// borrar categorias
		if ( ctx->pcats ) {
			SRVCAT *tmp,*sig;
			tmp=ctx->pcats;
			while ( tmp!=NULL ) {
				sig = tmp->sig;
				fct->free(tmp,ggs);
				tmp = sig;
			}
			ctx->pcats = NULL;
		}
		return TRUE;
	} // case WM_CLEARLST

	// Return the Dialog Face brush ---------------------------------------
	case WM_CTLCOLORSTATIC:
		SetTextColor( (HDC) wParam, cli->pMFrmCtx->hFontColor );
		SetBkMode( (HDC) wParam, TRANSPARENT );
		return (BOOL) cli->pMFrmCtx->hbrDlg;

	case WM_CTLCOLORDLG: 
		return (BOOL) cli->pMFrmCtx->hbrDlg;
	
	//15-Sept-05: Removed by wrong updates in the dialog background.
	/*case WM_ERASEBKGND:
	{
		HDC hdc;
		hdc = (HDC) wParam;
    
		RECT rc,rc2;
		GetWindowRect( hDlg,&rc );
		MapWindowPoints(NULL,hDlg,(POINT *)&rc,2);
		GetUpdateRect(hDlg,&rc2,FALSE);
		FillRect(hdc,&rc2,cli->pMFrmCtx->hbrDlg );
		rc.top +=1;
		rc.left+=4;
		rc.right-=4;
		rc.bottom = rc.top+3;
		DrawEdge(hdc,&rc,BDR_RAISEDOUTER,BF_RECT);
		if (ggs->Log) ggs->Log->AddStr(ggs," >CliExtend: background painted.\r\n");
		return 1;
	}*/

	// actualizar textos --------------------------------------------------
	// update strings -----------------------------------------------------
	case WM_UPDATETEXT:
		api->pSetDlgItemText( hDlg, IDC_SCAT , g_Ctx->str.sSLlblcat );
		api->pSetDlgItemText( hDlg, IDC_CAPTION , cli->str.sSLCaption );
		api->pSetDlgItemText( hDlg, IDC_SHOW , cli->str.sSLShow );
		api->pSetDlgItemText( hDlg, IDC_SENC2, cli->str.sESSenc );
		api->pSetDlgItemText( hDlg, IDC_SIO2 , cli->str.sESSnet );
		api->pSetDlgItemText( hDlg, IDC_SAUTH2,cli->str.sESSauth );
		api->pSetDlgItemText( hDlg, IDC_SNAME2,cli->str.sESSname );
		api->pSetDlgItemText( hDlg, IDC_SADD,  cli->str.sESSaddr );
		return TRUE;

	
	// Agregar los nombres de los modulos ---------------------------------
	// Add module names ---------------------------------------------------
	case WM_UPDATEMODULES:
	{
		char buf[10],*pName;
		int pos,i;
		HWND hCombo;

		// Add Encryption Modules
		hCombo = api->pGetDlgItem(hDlg,IDC_ENC);
		api->pSendMessage( hCombo, CB_RESETCONTENT, 0, 0 );
		for ( i=0; i<MAX_ENCRYPTION_ENGINES; i++ ) {
			pName = gv->EncHandler->Query(gv->EncHandler, i);
			if (pName!=NULL) {
				fct->strncpy(buf,pName,9);
				pos = fct->InString(buf,":");
					if (pos!=-1)
					buf[pos]=0;
				else
					buf[10]=0;
				api->pSendMessage( hCombo, CB_ADDSTRING, 0, (LPARAM) buf );
			}
		}
		api->pSendMessage( hCombo, CB_SETCURSEL, 0, 0 );

		// Add IO Modules
		hCombo = api->pGetDlgItem(hDlg,IDC_IO);
		api->pSendMessage( hCombo, CB_RESETCONTENT, 0, 0 );
		for ( i=0; i<MAX_IO_ENGINES; i++ ) {
			pName = gv->IOHandler->Query(gv->IOHandler, i);
			if (pName!=NULL) {
				fct->strncpy(buf,pName,9);
				pos = fct->InString(buf,":");
				if (pos!=-1)
					buf[pos]=0;
				else
					buf[10]=0;
				api->pSendMessage( hCombo, CB_ADDSTRING, 0, (LPARAM) buf );
			}
		}
		api->pSendMessage( hCombo, CB_SETCURSEL, 0, 0 );

		// Add Auth Modules
		hCombo = api->pGetDlgItem(hDlg,IDC_AUTH);
		api->pSendMessage( hCombo, CB_RESETCONTENT, 0, 0 );
		for ( i=0; i<MAX_AUTH_ENGINES; i++ ) {
			pName = gv->AuthHandler->Query(gv->AuthHandler, i);
			if (pName!=NULL) {
				fct->strncpy(buf,pName,9);
				pos = fct->InString(buf,":");
				if (pos!=-1)
					buf[pos]=0;
				else
					buf[10]=0;
				api->pSendMessage( hCombo, CB_ADDSTRING, 0, (LPARAM) buf );
			}
		}
		api->pSendMessage( hCombo, CB_SETCURSEL, 0, 0 );
		return TRUE;
	} // case WM_UPDATEMODULES

	// Tecla enter presionada ---------------------------------------------
	case WM_ENTERKEY:
	{
		TVITEM		Itm;
		HWND		hwnd = (HWND) wParam;
		SERVER_INFO	*nfo;

		// obtener el elemento seleccionado.
		// Get the selected item
		Itm.hItem = TreeView_GetSelection( ctx->hList );
		if ( Itm.hItem==NULL )
			return TRUE;

		// Obtener la clase de elemento
		// Get item type
		Itm.mask = TVIF_IMAGE|TVIF_PARAM;
		TreeView_GetItem( ctx->hList, &Itm );

		if ( Itm.iImage==3 )
			return TRUE;

		nfo = (SERVER_INFO *) Itm.lParam;
		if ( hwnd==api->pGetDlgItem(hDlg,IDC_NAME2) )
		{
			api->pSendMessage( hwnd, WM_GETTEXT, sizeof(nfo->svName), (LPARAM)nfo->svName );
			
			if ( UpdateSrvCRC(ggs,nfo) ) {
				cli->bSave = true;
				api->pSendMessage( hDlg, WM_UPDATESRV, (LPARAM) nfo, 0 );
				cli->pSetStatusText( ggs, cli->str.sSBsrvedit );
			}

		} else if( hwnd==api->pGetDlgItem(hDlg,IDC_ADD) ) {
			
			if ( api->pSendMessage( hwnd, WM_GETTEXTLENGTH, 0, 0 )== 0) {
				MessageBox(hDlg,str->sErrNulladdress,str->sErrTitle,MB_OK|MB_ICONSTOP );
				cli->pSetStatusText( ggs, cli->str.sStatusReady );
				return TRUE;
			}
			api->pSendMessage( hwnd, WM_GETTEXT, sizeof(nfo->svAddress), (LPARAM)nfo->svAddress );

			if ( UpdateSrvCRC(ggs,nfo) ) {
				cli->bSave = true;
				api->pSendMessage( hDlg, WM_UPDATESRV, (LPARAM) nfo, 0 );
				cli->pSetStatusText( ggs, cli->str.sSBsrvedit );
			}
		} else if ( hwnd==ctx->hList ) {
			api->pSendMessage(hDlg,WM_COMMAND,IDC_CONNECTMACHINE,0);
		}

		return TRUE;
	}

	// Tecla 'Esc' presionada ---------------------------------------------
	case WM_ESCKEY:
	{
		if ( ctx->bDrag ) {
			ImageList_DragLeave(ctx->hList);
			ImageList_EndDrag(); 
			
			TreeView_SelectDropTarget(ctx->hList, NULL); 
			ReleaseCapture(); 
			ctx->bDrag = false; 
#ifdef _DEBUG
			if ( ggs->Log ) ggs->Log->AddStr( ggs, " >CliExtend: Drag Operarion canceled.\r\n" );
#endif
		}
		return TRUE;
	}

	// --------------------------------------------------------------------
	// Delete and Clean up this Window ------------------------------------
	case WM_DESTROY: 
		if ( ctx ) {

			HWND hLoc=api->pGetDlgItem(hDlg,IDC_NAME2);
			api->pSetWindowLong(hLoc,GWL_WNDPROC,api->pGetWindowLong(hLoc,GWL_USERDATA));

			hLoc=api->pGetDlgItem(hDlg,IDC_ADD);
			api->pSetWindowLong(hLoc,GWL_WNDPROC,api->pGetWindowLong(hLoc,GWL_USERDATA));

			hLoc=ctx->hList;
			api->pSetWindowLong(hLoc,GWL_WNDPROC,api->pGetWindowLong(hLoc,GWL_USERDATA));

			DestroyIcon( ctx->hConnMach );
			DestroyIcon( ctx->hDelMach );
			DestroyIcon( ctx->hEditMach );
			DestroyIcon( ctx->hNewMach );
			DestroyMenu( ctx->hMenuCtx );
			ImageList_Destroy( ctx->hImgLst );

			api->pSetWindowLong( hDlg, GWL_USERDATA, 0 );
			fct->free( ctx, ggs );
		}
#ifdef _DEBUG
		if (ggs->Log) ggs->Log->AddStrf( ggs, " >CliExtend: Server List Dialog Destroyed. Context address: %#x.\r\n",ctx);
#endif
		return TRUE;
	} // case WM_DESTROY

	return FALSE;
}








///////////////////////////////////////////////////////////////////////////
BOOL CALLBACK CategoryAddDlgProc ( HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam ) 
{
	CLI *cli = ggs->cli;
	API *api = &(ggs->api);
	SRVLST_STR *str = &g_Ctx->str;
	switch (uMsg) 
    { 
	// ----------------------------------------------------
	// Initailize Main Dialog -----------------------------
	case WM_INITDIALOG:
		{
			api->pSetWindowLong(hDlg,GWL_USERDATA,lParam);
			cli->pDoFlatBtn( ggs, api->pGetDlgItem( hDlg,IDOK ) );
			cli->pDoFlatBtn( ggs, api->pGetDlgItem( hDlg, IDCANCEL) );

			api->pSetWindowText( hDlg, str->sACtitulo );
			api->pSetDlgItemText( hDlg, IDC_SCATNAME, str->sACscatname  );
			api->pSetDlgItemText( hDlg, IDOK        , str->sACsok );
			api->pSetDlgItemText( hDlg, IDCANCEL    , str->sACscancel );
			api->pSetDlgItemText( hDlg, IDC_CATNAME , (char *) lParam );
			
		#ifdef _DEBUG
			if (ggs->Log) ggs->Log->AddStr( ggs, " >CliExtend: Add Category dialog created.\r\n");
		#endif

			return TRUE;
		}
	
	// ----------------------------------------------------
	// Command Messages -----------------------------------
	case WM_COMMAND:
		{
			switch (LOWORD(wParam)) 
			{
				case IDOK:
				{
					FCT *fct = &ggs->fct;
					
					char *stmp = (char *) fct->malloc(64,ggs);
					char *sNombre = (char *) api->pGetWindowLong( hDlg, GWL_USERDATA );
					api->pGetDlgItemText(hDlg,IDC_CATNAME,stmp,63);
					if ( *stmp==0 ) {
						api->pMessageBox( hDlg,str->sErrNullcatname ,str->sErrTitle ,MB_OK|MB_ICONSTOP);
						return TRUE;
					}

					fct->strncpy( sNombre,stmp,63);
					fct->free(stmp,ggs);
					api->pEndDialog( hDlg, 1 );
					return TRUE;
				}

				case IDCANCEL:
					api->pEndDialog( hDlg, 0 );
					return TRUE;

			}
			break;
		}

	// Support for flat buttons.
	case WM_DRAWITEM:
		ggs->api.pSendMessage( ((LPDRAWITEMSTRUCT) lParam)->hwndItem, uMsg, (WPARAM)cli->pMFrmCtx->hbrDlg, lParam);
		return TRUE;

	// Return the Dialog Face brush ---------------------------------------
	case WM_CTLCOLORSTATIC:
		SetBkMode( (HDC) wParam, TRANSPARENT );
		return (BOOL) cli->pMFrmCtx->hbrDlg;

	case WM_CTLCOLORDLG: 
		return (BOOL) cli->pMFrmCtx->hbrDlg;

	// ----------------------------------------------------
	// Delete and Clean up this Window --------------------
	case WM_DESTROY: 
	#ifdef _DEBUG
		if (ggs->Log) ggs->Log->AddStr( ggs, " >CliExtend: Add Category dialog destroyed.\r\n");
	#endif
		return TRUE; 
	}
	return FALSE;
}
