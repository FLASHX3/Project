/*  Client Extensions for Back Orifice XP
    Copyright (C) 2,004 - 2,005 Javier Aroche
	
	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

> Autor: Javier Aroche, j_aroche at users dot sourceforge dot net */

#ifndef __TRAYICON_EXT_H_
#define __TRAYICON_EXT_H_

#include <srv_linkage.h>

#define WM_TRAYICON		0x1337
#define TRAYICONID		0x1982	// Tray Icon ID
#define TRAY_TIMEID		0x629a	// Tray Icon Timer ID

// Client Extensions :: Tray Icon context.
typedef struct {
	HMENU		hMenu;		// Trayicon context menu.
} CETRAYICON_CTX;

extern bool BOAPI InstallTrayIconExtension ( GS *gs );
extern void BOAPI UninstallTrayIconExtension ( GS *gs );

#endif