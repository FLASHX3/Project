//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by cli_extend.rc
//
#define IDD_SRVLST                      101
#define IDB_SRVLIST                     102
#define IDI_MAS                         103
#define IDI_MENOS                       104
#define IDI_CONF                        105
#define IDI_CONN                        106
#define IDI_CATADD                      107
#define IDI_CATDEL                      109
#define IDD_CATEGORYADD                 110
#define IDI_CATEDIT                     122
#define IDR_CTX                         123
#define IDD_FINDSRVEX                   124
#define IDI_FIND                        126
#define IDC_SRVLST                      1000
#define IDC_CAT                         1001
#define IDC_SCAT                        1002
#define IDC_SENC2                       1003
#define IDC_ENC                         1004
#define IDC_SIO2                        1005
#define IDC_IO                          1006
#define IDC_CAPTION                     1007
#define IDC_SHOW                        1008
#define IDC_NEWMACHINE                  1009
#define IDC_DELETEMACHINE               1010
#define IDC_EDITMACHINE                 1011
#define IDC_CONNECTMACHINE              1012
#define IDC_SAUTH2                      1013
#define IDC_AUTH                        1014
#define IDC_NAME2                       1015
#define IDC_SNAME2                      1016
#define IDC_SADD                        1017
#define IDC_ADD                         1018
#define IDC_CATADD                      1019
#define IDC_CATDEL                      1020
#define IDC_CATNAME                     1021
#define IDC_FINDMACHINE                 1021
#define IDC_SCATNAME                    1022
#define IDC_CATEDIT                     1023
#define IDC_SELCAT                      1025
#define IDC_FIND                        1080
#define IDC_SRVNAME                     1081
#define IDC_SSRVNAME                    1082
#define IDC_SSRVDIR                     1083
#define IDC_SRVDIR                      1084
#define IDC_SMSG                        1086
#define IDMC_EDITSRV                    40002
#define IDMC_DELETESRV                  40003
#define IDMC_CONNECT                    40004
#define IDMC_DISCONNECT                 40005
#define IDMC_EDITCAT                    40006
#define IDMC_DELCAT                     40007
#define IDM_TI_SHOW                     40008
#define IDM_TI_EXIT                     40009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        127
#define _APS_NEXT_COMMAND_VALUE         40010
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
