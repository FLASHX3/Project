/*  Client Extensions for Back Orifice XP
    Copyright (C) 2,004 - 2,005 Javier Aroche
	
	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

> Autor: Javier Aroche, j_aroche at users dot sourceforge dot net */

// ---------------------------------------------------
// main.cpp:
// Provides the link between this DLL and the boxp client
//
// History:
//		> v0.0		16-May-04		* File Added to project
//		> v0.91		20-Mar-05		* Fix: check if the ServerList is visible at startup
//					25-Jul-05		* Added "Enable Tray Icon" configuration variable.
//					27-Jul-05		* Some changes to improve the installation/uninstallation
//									  of the extensions.
//					07-Aug-05		* Linking main.h header.
// ---------------------------------------------------

#include "serverlist.h"
#include "trayicon.h"
#include "main.h"

// ------------ Global Vars -------------------------------

HINSTANCE g_hInstance;
BOOL g_bActive;
char g_sCliExtendCfg[]="<**CFG**>Client Extensions\0"
					  "B:Extend ServerList=1\0"
					  "B:Enable Tray Icon=1\0";
CLIEXT	*g_Ctx;
GS		*ggs;
bool	g_bSrvLstInst;
bool	g_bTrayIconInst; 

char g_sCliExtStrings[]=
"BOXP Neighborhood\0"
"Add Category\0"
"Edit Category\0"
"Remove Category\0"
"Press Enter to change the value\0"
"Cate&gory:\0"
"(None)\0"

"Category Added.\0"
"Category Edited.\0"
"Category Removed.\0"
"Server Categorized.\0"

"Server Address can't be NULL!\0"
"The category name can't be NULL.\0"
"Cli_extend: Error\0"

"Add/Edit Category\0"
"&Category name:\0"
"&OK\0"
"C&ancel\0"

"CliExtend Find Server Thread\0"
"(All categories)\0"
;



// ------------- Function Implementations ------------------
BOOL WINAPI DllMain(HINSTANCE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
	switch (ul_reason_for_call) {
	case DLL_PROCESS_ATTACH:
		g_hInstance=hInst;
		break;
	}
	return TRUE;
}

// Instalation function: called by the Server and Client
bool BOAPI InitPlugin ( GS *gs, PI *pv )
{
	if ( gs->nSize!=sizeof(GS) ) return false;
	
	if ( gs->cli==NULL ) return false;

#ifdef _DEBUG
	if (gs->Log) gs->Log->AddStr(gs, " >CliExtend: Init Plug. (C) 2004-05 Javier Aroche\r\n");
#endif

	CLI *cli = gs->cli;
	FCT *fct = &gs->fct;
	g_bActive    = TRUE;
	ggs = gs;
	g_Ctx = (CLIEXT *) fct->malloc( sizeof(CLIEXT),gs );
	if ( g_Ctx==NULL ) {
#ifdef _DEBUG
		if (gs->Log) gs->Log->AddStr(gs, " *CliExtend: Error when alloc main ctx memory.\r\n");
#endif
		return false;
	}

	// Copiar cadenas
	// copy strings
	g_Ctx->str.pSpace = (char *)fct->malloc( sizeof(g_sCliExtStrings), gs );
	fct->memcpy( g_Ctx->str.pSpace, g_sCliExtStrings, sizeof(g_sCliExtStrings) );
	fct->LoadStrings( gs, &g_Ctx->str.sSLtvroot, g_Ctx->str.pSpace );

	// Instalar nuevo Server List
	// Install new Server List
	if ( gs->fct.GetCfgBool(gs,g_sCliExtendCfg,"Extend ServerList") ) {
		InstallServerListExtension(gs);
		g_bSrvLstInst = true;
	} else
		g_bSrvLstInst = false;

	// Instalar Tray Icon
	// Install Tray Icon
	if ( gs->fct.GetCfgBool(gs,g_sCliExtendCfg,"Enable Tray Icon") ) {
		InstallTrayIconExtension(gs);
		g_bTrayIconInst = true;
	} else
		g_bTrayIconInst = false;

	return true;
}

// Uninstalation function: called by the Server and Client
void BOAPI DelPlugin ( GS *gs )
{
	CLI *cli = gs->cli;
	API *api = &gs->api;
	g_bActive=FALSE;

	if ( cli ) {
		
		if ( g_bSrvLstInst ) {
			UninstallServerListExtension(gs);
			g_bSrvLstInst = false;
		}

		if ( g_bTrayIconInst ) {
			UninstallTrayIconExtension(gs);
			g_bTrayIconInst = false;
		}

		gs->fct.free(g_Ctx->str.pSpace, gs );
		gs->fct.free(g_Ctx,gs);
		g_Ctx=NULL;
	}

#ifdef _DEBUG
	if (gs->Log) gs->Log->AddStr(gs, " >CliExtend: Delete Function\r\n");
#endif
}

// Plugin Information function: called by the Server, Client and Configutarion tool
bool BOAPI PlugVer ( PLUGIN_INFO *pv )
{
	pv->wVerLo		= 93;
	pv->wVerHi		= 0;
	pv->wHiBOVer	= 1;
	pv->wLoBOVer	= 00;
	pv->svID		= "CLIEXTEND\0";
	pv->svName		= "cli_extend.dll";
	pv->svDesc		= "BOXP Client Extensions by J. Aroche (C) 2004-05";
	pv->pConfigStr	= g_sCliExtendCfg;
	pv->nConfigLen	= sizeof(g_sCliExtendCfg);
	pv->bRunAsThread= false;
	pv->Flags		= PF_CLI;
	pv->Type		= PLG_CMD|PLG_PATCH;
	return true;
}
