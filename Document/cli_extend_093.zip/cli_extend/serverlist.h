/*  Client Extensions for Back Orifice XP
    Copyright (C) 2,004 - 2,005 Javier Aroche
	
	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

> Autor: Javier Aroche, j_aroche at users dot sourceforge dot net */

#ifndef __SRVLISTEXT_H_
#define __SRVLISTEXT_H_

#include <srv_linkage.h>
#include <bogui.h>

// Definiciones
#define	WM_ADDCATEGORY		WM_USER+0x150
#define WM_DELCATEGORY		WM_USER+0x151
#define WM_EDITCATEGORY		WM_USER+0x152
#define WM_CATEGORIZAR		WM_USER+0x153
#define WM_UPDATEMODULES	WM_USER+0x154
#define WM_ENTERKEY			WM_USER+0x155
#define WM_ESCKEY			WM_USER+0x156

// BOXP Extension del Documento
typedef struct {
	DWORD	dwCrc;			// Checksum
	WORD	nCats;			// Numero de categorias
	WORD	nServerCat;		// Servidores Categorizados.
	void	*sig_estr;		// Siguiente Estructura.
} BODOCEX;

// BODOCEX::Info de las Categorias.
typedef struct {
	char		sNombre[65];
	bool		bExpandido;
} CAT_INFO;

// BODOCEX::Servidores en categoria
typedef struct {
	DWORD	dwCatID;		// ID de la categoria
	DWORD	dwSrvID;		// ID del servidor.
} SRVINCAT;

// Server Category Structure.
typedef struct srvcat {
	char		c;				// sign
	char		sNombre[65];	// Nombre de la Categoria.

	DWORD		nCRC;			// Checksum
	HTREEITEM	itm;			// TreeView item id.
	struct srvcat *sig;			// Siguiente Categoria.
	bool		bExpandido;		// Esta expandido?
} SRVCAT;

// CLIEXT::ServerList Extension Context structure
// Note: must be alike the original structure, new members goes at bottom
typedef struct {
	HWND	hSrvList;		// Server List Window
	HWND	hList;			// TreeView Control.
	HWND	hToolTips;		// ToolTips Control.
	int		wndheight;		// Window height
	HIMAGELIST hImgLst;		// ImageList 

	HICON	hDelMach;		// Delete Machine Icon
	HICON	hConnMach;		// Connect Machine Icon
	HICON	hEditMach;		// Edit Machine Icon
	HICON	hNewMach;		// New Machine Icon
	HICON	hFindMach;		// Find Machine Icon

	bool	bShowDetails;	// Show all server info?
	int		wndwidth;		// Window width
	HICON	hCatAdd;		// Add Category Icon.
	HICON	hCatDel;		// Delete Category Icon.
	HICON	hCatEdit;		// Edit Category Icon.

	int		nLastSort;		// Last column used to sort
	BOOL	bInvSort;		// should invert sort?

	SRVCAT	*pcats;			// Categorias.

	bool	bDrag;			// Arrastrando?
	HTREEITEM hDragItem;
	HMENU	hMenuCtx;		// menu de contexto

} SRVLST2_CTX,SLC2;

// CLIEXT::FindSrv extended dialog context
typedef struct {
	HWND		hDlg;
	HWND		hParent;
	char 		sName[65];		// server name to find
	char		sAddr[65];		// server address to find

	DWORD		dwCRCName;		// Name CRC value
	DWORD		dwCRCAddr;		// Address CRC value

	SERVER_INFO	*pSelSrv;		// current server in the search

	int			nSelCat;		// Selected category.
	HTREEITEM	hSelSrv;		// current sever in the search by category

} FINDSRV2_CTX,FSC2;

extern void BOAPI InstallServerListExtension ( GS *gs );
extern void BOAPI UninstallServerListExtension ( GS *gs );
extern SRVLIST_CTX * BOAPI CreateSrvLstExDlg( GS *gs, HWND hParent );
extern BOOL CALLBACK ServerListExProc (HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam);

#endif