/*  Client Extensions for Back Orifice XP
    Copyright (C) 2,004 - 2,005 Javier Aroche
	
	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.
	
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
	GNU General Public License for more details.
	
	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA

> Autor: Javier Aroche, j_aroche at users dot sourceforge dot net */

// ---------------------------------------------------
// trayicon.cpp:
// Source Code of the BOGUI Tray Icon
//
// History:
//		> v0.91		23-Jul-05		* Added to project.
//					26-Jul-05		* Added install and uninstall functions, just handles the
//									  trayicon registration for now.
//					07-Aug-05		* Linking main.h header.
//									* Subclassing MainFrame window.
//		> v0.93		14-Sep-05		* Trayicon Inteface working now. Hides MainFrame when it's 
//									  minimized. On left click shows the MainFrame. On right 
//									  click shows the context menu.
///////////////////////////////////////////////////////////////////////////

#include "main.h"
#include "trayicon.h"
#include "resource.h"


LRESULT SubMainFrmProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

bool BOAPI InstallTrayIconExtension ( GS *gs ) 
{
	CLI *cli = gs->cli;

	/////////////////////////
	// 1. Crear Tray Icon
	//    Create tray icon
    NOTIFYICONDATA tnid; 

	g_Ctx->tictx = (CETRAYICON_CTX *) gs->fct.malloc(sizeof(CETRAYICON_CTX),gs);
	if ( g_Ctx->tictx==NULL )
		return false;

	g_Ctx->tictx->hMenu = LoadMenu(g_hInstance,MAKEINTRESOURCE(IDR_CTX));
 
    tnid.cbSize = sizeof(NOTIFYICONDATA); 
    tnid.hWnd = cli->hMainWnd; 
    tnid.uID = TRAYICONID; 
    tnid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP; 
    tnid.uCallbackMessage = WM_TRAYICON; 
    tnid.hIcon = cli->hicoBoguiSml; 
    gs->fct.strncpy(tnid.szTip, cli->str.sAppName, gs->fct.strlen(cli->str.sAppName) ); 
	if ( !Shell_NotifyIcon(NIM_ADD, &tnid) ) {
		if (gs->Log) gs->Log->AddStr(gs," *CliExtend: Error creating Tray Icon.\r\n" );
		return false;
	}

	/////////////////////////
	// 2. Guardar Direcciones.
	//    Save addresses
	g_Ctx->pOldMainFrameProc = cli->pMainFrameProc;


	/////////////////////////
	// 3. Subclass MainFrame
	SetWindowLong(cli->hMainWnd,GWL_WNDPROC, (LONG) SubMainFrmProc );
	cli->pMainFrameProc = SubMainFrmProc;

 
	if (gs->Log) gs->Log->AddStr(gs," >CliExtend: Tray Icon Installed.\r\n" );

	return true;
}

void BOAPI UninstallTrayIconExtension ( GS *gs ) 
{
	CLI * cli = gs->cli;

	/////////////////////////
	// 1. Eliminar tray icon
	//    Remove tray icon

	NOTIFYICONDATA tnid; 
    tnid.cbSize = sizeof(NOTIFYICONDATA); 
    tnid.hWnd = cli->hMainWnd;
    tnid.uID = TRAYICONID; 
    Shell_NotifyIcon( NIM_DELETE, &tnid ); 

	DestroyMenu( g_Ctx->tictx->hMenu );
	gs->fct.free( g_Ctx->tictx,gs );
	g_Ctx->tictx = NULL;

	/////////////////////////
	// 2. Restablecer Main Frame
	//    Recover Main Frame.
	cli->pMainFrameProc = g_Ctx->pOldMainFrameProc;
	SetWindowLong(cli->hMainWnd,GWL_WNDPROC, (LONG) cli->pMainFrameProc );

	if (gs->Log) gs->Log->AddStr(gs," >CliExtend: Tray Icon Uninstalled.\r\n" );
}

LRESULT SubMainFrmProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	API *api=&ggs->api;
	if (message==WM_ACTIVATE)
	{
	    if ( (BOOL) HIWORD(wParam) ) 
			api->pShowWindow(ggs->cli->hMainWnd,SW_HIDE);

	    return CallWindowProcA(g_Ctx->pOldMainFrameProc,ggs->cli->hMainWnd,message,wParam,lParam);
	}

	if (message==WM_TRAYICON) {
		if ( ((UINT)wParam) == TRAYICONID )
		{
			switch((UINT) lParam)
			{
			// Show the Main Dialog ---------------------------------------
			case WM_LBUTTONDOWN:
				if ( api->pIsWindowVisible(ggs->cli->hMainWnd)==FALSE )
					api->pShowWindow(ggs->cli->hMainWnd,SW_RESTORE);
				SetForegroundWindow(hDlg);
				return TRUE;

			case WM_RBUTTONDOWN:
				POINT pt;
				GetCursorPos(&pt);

				HMENU hSM = GetSubMenu( g_Ctx->tictx->hMenu, 2 );
				DWORD nCmd = TrackPopupMenu(hSM,TPM_RETURNCMD|TPM_NONOTIFY,pt.x,pt.y,0,hDlg,NULL);
				switch(nCmd) {
					case IDM_TI_SHOW:
						if ( api->pIsWindowVisible(ggs->cli->hMainWnd)==FALSE )
							api->pShowWindow(ggs->cli->hMainWnd,SW_RESTORE);
						SetForegroundWindow(hDlg);
						return TRUE;
					case IDM_TI_EXIT:
						if ( api->pIsWindowVisible(ggs->cli->hMainWnd)==FALSE )
							api->pShowWindow(ggs->cli->hMainWnd,SW_RESTORE);
						api->pSendMessage(ggs->cli->hMainWnd,WM_CLOSE,0,0);
				}
				return TRUE;
			}
		}
		return TRUE;
	} 
	return CallWindowProcA(g_Ctx->pOldMainFrameProc,ggs->cli->hMainWnd,message,wParam,lParam);
}